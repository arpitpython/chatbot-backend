/**
 * sidebar-init.js - Initialization code for sidebars
 * Add this script to your index.html after loading all components
 */

// Track whether all components have been loaded
let componentsLoaded = {
    'navbar-container': false,
    'sidebar-container': false,
    'chat-container': false,
    'document-container': false
};

// Listen for component loaded events
document.addEventListener('componentLoaded', function(e) {
    if (e.detail.containerId in componentsLoaded) {
        componentsLoaded[e.detail.containerId] = true;
        
        // Check if all components are loaded
        checkAllComponentsLoaded();
    }
});

// Check if all components are loaded and initialize
function checkAllComponentsLoaded() {
    const allLoaded = Object.values(componentsLoaded).every(loaded => loaded);
    
    if (allLoaded) {
        console.log('All components loaded. Initializing sidebar functionality...');
        initializeSidebarFunctionality();
    }
}

// Initialize sidebar functionality after all components are loaded
function initializeSidebarFunctionality() {
    // Set initial state for both sidebars
    setInitialSidebarStates();
    
    // Initialize toggle buttons
    initializeToggleButtons();
    
    // Adjust chat container space
    if (typeof adjustChatContainerSpace === 'function') {
        adjustChatContainerSpace();
    } else if (typeof window.adjustChatContainerSpace === 'function') {
        window.adjustChatContainerSpace();
    }
    
    // Add window resize handler
    window.addEventListener('resize', function() {
        // Delay execution slightly to allow other resize handlers to complete
        setTimeout(function() {
            if (typeof adjustChatContainerSpace === 'function') {
                adjustChatContainerSpace();
            } else if (typeof window.adjustChatContainerSpace === 'function') {
                window.adjustChatContainerSpace();
            }
        }, 100);
    });
}

// Set initial states for the sidebars
function setInitialSidebarStates() {
    const sidebarContainer = document.getElementById('sidebar-container');
    const documentContainer = document.getElementById('document-container');
    
    // Default state is expanded for sidebar, collapsed for document viewer
    if (sidebarContainer) {
        if (!sidebarContainer.classList.contains('expanded') && 
            !sidebarContainer.classList.contains('collapsed')) {
            sidebarContainer.classList.add('expanded');
        }
    }
    
    if (documentContainer) {
        if (!documentContainer.classList.contains('expanded') && 
            !documentContainer.classList.contains('collapsed')) {
            documentContainer.classList.add('collapsed');
            
            // Show document collapsed toggle
            const documentCollapsedToggle = document.getElementById('document-collapsed-toggle');
            if (documentCollapsedToggle) {
                documentCollapsedToggle.style.display = 'flex';
            }
        }
    }
}

// Initialize toggle buttons functionality
function initializeToggleButtons() {
    // Sidebar toggle buttons
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebarCollapsedToggle = document.getElementById('sidebar-collapsed-toggle');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            if (typeof toggleSidebar === 'function') {
                toggleSidebar('sidebar-container');
            } else if (typeof window.toggleSidebar === 'function') {
                window.toggleSidebar('sidebar-container');
            }
        });
    }
    
    if (sidebarCollapsedToggle) {
        sidebarCollapsedToggle.addEventListener('click', function() {
            if (typeof toggleSidebar === 'function') {
                toggleSidebar('sidebar-container');
            } else if (typeof window.toggleSidebar === 'function') {
                window.toggleSidebar('sidebar-container');
            }
        });
    }
    
    // Document viewer toggle buttons
    const documentToggle = document.getElementById('document-toggle');
    const documentCollapsedToggle = document.getElementById('document-collapsed-toggle');
    
    if (documentToggle) {
        documentToggle.addEventListener('click', function() {
            if (typeof toggleDocumentViewer === 'function') {
                toggleDocumentViewer();
            } else if (typeof window.toggleDocumentViewer === 'function') {
                window.toggleDocumentViewer();
            }
        });
    }
    
    if (documentCollapsedToggle) {
        documentCollapsedToggle.addEventListener('click', function() {
            if (typeof toggleDocumentViewer === 'function') {
                toggleDocumentViewer();
            } else if (typeof window.toggleDocumentViewer === 'function') {
                window.toggleDocumentViewer();
            }
        });
    }
    
    // Check initial visibility of collapsed toggle buttons
    updateCollapsedToggleVisibility();
}

// Update collapsed toggle buttons visibility
function updateCollapsedToggleVisibility() {
    const sidebarContainer = document.getElementById('sidebar-container');
    const documentContainer = document.getElementById('document-container');
    const sidebarCollapsedToggle = document.getElementById('sidebar-collapsed-toggle');
    const documentCollapsedToggle = document.getElementById('document-collapsed-toggle');
    
    // Update sidebar toggle visibility
    if (sidebarCollapsedToggle && sidebarContainer) {
        sidebarCollapsedToggle.style.display = 
            sidebarContainer.classList.contains('collapsed') ? 'flex' : 'none';
    }
    
    // Update document toggle visibility
    if (documentCollapsedToggle && documentContainer) {
        documentCollapsedToggle.style.display = 
            documentContainer.classList.contains('collapsed') ? 'flex' : 'none';
    }
}

// Add additional CSS for smooth transitions
function addTransitionStyles() {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
        /* Ensure smooth transitions for sidebar elements */
        #sidebar-container, #document-container, #chat-container {
            transition: all 0.3s ease;
        }
        
        /* Make sure collapsed sidebars don't take space */
        #sidebar-container.collapsed, #document-container.collapsed {
            width: 0 !important;
            min-width: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
            overflow: hidden !important;
        }
        
        /* Ensure collapsed toggle buttons are visible */
        .collapsed-toggle {
            z-index: 1000 !important;
            background-color: var(--secondary-color) !important;
            color: white !important;
        }
        
        /* Collapsed toggle button animation */
        @keyframes pulse {
            0% { transform: translateY(-50%) scale(1); }
            50% { transform: translateY(-50%) scale(1.1); }
            100% { transform: translateY(-50%) scale(1); }
        }
    `;
    
    document.head.appendChild(styleElement);
}

// Run the transition styles immediately
addTransitionStyles();

// Manually trigger initialization if it hasn't happened after a delay
setTimeout(function() {
    const allLoaded = Object.values(componentsLoaded).every(loaded => loaded);
    if (!allLoaded) {
        console.log('Some components may not have loaded. Initializing anyway...');
        initializeSidebarFunctionality();
    }
}, 2000);

