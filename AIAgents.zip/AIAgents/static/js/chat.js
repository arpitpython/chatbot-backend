/**
 * Chat functionality for the document chatbot
 * Handles user input, sending messages, and displaying responses
 */

// Current active document ID
let currentDocumentId = null;

// Wait for the chat component to load
document.addEventListener('componentLoaded', function(e) {
    if (e.detail.containerId === 'chat-container') {
        initializeChat();
    }
});

// Listen for document selection
document.addEventListener('documentSelected', function(e) {
    currentDocumentId = e.detail.documentId;
});

/**
 * Initialize chat functionality
 */
function initializeChat() {
    setupUserInput();
    setupSendButton();
    
    // Ensure conversation container is always scrolled to the bottom initially
    const conversationContainer = document.querySelector('.conversation-container');
    if (conversationContainer) {
        setTimeout(() => {
            conversationContainer.scrollTop = conversationContainer.scrollHeight;
        }, 100);
    }
}

/**
 * Set up the user input textarea with auto-resize
 */
function setupUserInput() {
    const userInput = document.getElementById('user-input');
    
    if (userInput) {
        // Set initial height
        userInput.style.height = 'auto';
        userInput.style.height = userInput.scrollHeight + 'px';
        
        // Auto-resize the textarea as user types
        userInput.addEventListener('input', function() {
            autoResizeTextarea(userInput);
        });
        
        // Send message on Enter key (but allow Shift+Enter for new lines)
        userInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
        
        // Focus the input when the page loads
        setTimeout(() => {
            userInput.focus();
        }, 500);
    }
}

/**
 * Set up the send button functionality
 */
function setupSendButton() {
    const sendButton = document.getElementById('send-button');
    
    if (sendButton) {
        sendButton.addEventListener('click', sendMessage);
    }
}

/**
 * Send a user message to the chatbot
 */
function sendMessage() {
    const userInput = document.getElementById('user-input');
    const message = userInput.value.trim();
    
    if (!message) {
        return;
    }
    
    // Add the user message to the chat
    addMessageToChat(message, 'user');
    
    // Clear the input field
    userInput.value = '';
    userInput.style.height = 'auto';
    
    // Focus back on the input
    userInput.focus();
    
    // Process the message and generate a response
    processUserMessage(message);
}

/**
 * Add a message to the chat
 * @param {string} content - The message content
 * @param {string} sender - The message sender ('user' or 'bot')
 */
function addMessageToChat(content, sender) {
    const conversationContainer = document.querySelector('.conversation-container');
    const currentTime = getCurrentTime();
    
    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    
    // Format the message content with simple markdown
    const formattedContent = formatMessageContent(content);
    
    // Set the inner HTML
    messageDiv.innerHTML = `
        <div class="message-content">
            ${formattedContent}
        </div>
        <div class="message-timestamp">${currentTime}</div>
    `;
    
    // Add to conversation
    conversationContainer.appendChild(messageDiv);
    
    // Scroll to the bottom
    scrollChatToBottom();
}

/**
 * Scroll the chat to the bottom
 */
function scrollChatToBottom() {
    const conversationContainer = document.querySelector('.conversation-container');
    if (conversationContainer) {
        // Using setTimeout to ensure this happens after DOM updates
        setTimeout(() => {
            conversationContainer.scrollTop = conversationContainer.scrollHeight;
        }, 10);
    }
}

/**
 * Format message content with simple markdown
 * @param {string} content - The raw message content
 * @returns {string} Formatted HTML content
 */
function formatMessageContent(content) {
    let formattedContent = content;
    
    // Convert URLs to links
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    formattedContent = formattedContent.replace(urlRegex, '<a href="$1" target="_blank">$1</a>');
    
    // Convert line breaks to <br> tags
    formattedContent = formattedContent.replace(/\n/g, '<br>');
    
    // Return as paragraph
    return `<p>${formattedContent}</p>`;
}

/**
 * Process the user message and generate a response
 * @param {string} message - The user message
 */
function processUserMessage(message) {
    if (!currentDocumentId) {
        // No document selected
        addMessageToChat('Please select a document from the sidebar first.', 'bot');
        return;
    }
    
    // In a real application, this would call your backend API to process the message
    // For demo purposes, we'll simulate a response after a short delay
    
    // Show typing indicator
    showTypingIndicator();
    
    // Simulate API processing time
    setTimeout(() => {
        // Hide typing indicator
        hideTypingIndicator();
        
        // Generate a simulated response
        const response = generateSimulatedResponse(message, currentDocumentId);
        
        // Add the bot response to the chat
        addMessageToChat(response, 'bot');
    }, 1500);
}

/**
 * Show typing indicator while waiting for the bot response
 */
function showTypingIndicator() {
    const conversationContainer = document.querySelector('.conversation-container');
    
    // Create typing indicator
    const typingIndicator = document.createElement('div');
    typingIndicator.className = 'message bot-message typing-indicator';
    typingIndicator.innerHTML = `
        <div class="message-content">
            <div class="typing-dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    `;
    
    conversationContainer.appendChild(typingIndicator);
    scrollChatToBottom();
}

/**
 * Hide the typing indicator
 */
function hideTypingIndicator() {
    const typingIndicator = document.querySelector('.typing-indicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

/**
 * Generate a simulated response (for demo purposes)
 * @param {string} userMessage - The user's message
 * @param {string} documentId - The active document ID
 * @returns {string} The simulated response
 */
function generateSimulatedResponse(userMessage, documentId) {
    // In a real application, this would be replaced with actual document analysis
    // and natural language processing to generate relevant responses
    
    const lowerMessage = userMessage.toLowerCase();
    
    // Check for common question patterns
    if (lowerMessage.includes('summary') || lowerMessage.includes('summarize')) {
        return `Based on my analysis of the document, here are the key points:\n\n• The document discusses quarterly financial performance\n• Revenue increased by 15% year-over-year\n• Operating expenses were reduced by 7%\n• The company launched 3 new products in this quarter\n• The board approved expansion into European markets`;
    }
    
    if (lowerMessage.includes('find') || lowerMessage.includes('where') || lowerMessage.includes('search')) {
        return `I found several relevant sections in the document:\n\n1. Page 3, paragraph 2 mentions "${userMessage.split(' ').slice(-1)[0]}"\n2. Page 7 has a table with detailed information\n3. The appendix contains additional references`;
    }
    
    if (lowerMessage.includes('compare') || lowerMessage.includes('difference')) {
        return `When comparing the data points you mentioned:\n\n• The first quarter shows a 12% growth rate\n• The second quarter increased to 15%\n• This represents a 3 percentage point improvement\n• The primary factors were new product launches and market expansion`;
    }
    
    // Default responses
    const defaultResponses = [
        `Based on the document, I can tell you that the information you're looking for appears on pages 4-7, in the section titled "Financial Analysis".`,
        `The document indicates that this topic was discussed in the executive summary. The key insight is that strategic initiatives led to a 22% increase in market share.`,
        `According to the document, this matter was addressed in the recent board meeting, with a decision to allocate additional resources to the project.`,
        `The document mentions this specifically in the recommendations section, suggesting a phased approach for implementation over the next two quarters.`
    ];
    
    // Return a random default response
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
}

/**
 * Auto-resize textarea based on content
 * @param {HTMLTextAreaElement} textarea - The textarea element to resize
 */
function autoResizeTextarea(textarea) {
    // Reset height to allow proper calculation
    textarea.style.height = 'auto';
    
    // Limit max height for usability
    const maxHeight = 100; // Reduced max height to ensure it fits better
    const scrollHeight = textarea.scrollHeight;
    
    if (scrollHeight > maxHeight) {
        textarea.style.height = maxHeight + 'px';
        textarea.style.overflowY = 'auto';
    } else {
        textarea.style.height = scrollHeight + 'px';
        textarea.style.overflowY = 'hidden';
    }
    
    // Make sure the chat input container adjusts accordingly
    const chatInputContainer = document.querySelector('.chat-input-container');
    if (chatInputContainer) {
        const newHeight = Math.min(scrollHeight + 30, maxHeight + 30); // 30px for padding
        chatInputContainer.style.height = newHeight + 'px';
    }
}

/**
 * Add custom styling for the typing indicator
 */
(function addTypingIndicatorStyles() {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
        .typing-dots {
            display: flex;
            gap: 4px;
        }
        
        .typing-dots span {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: var(--gray-medium);
            display: inline-block;
            animation: typingDot 1.4s infinite ease-in-out both;
        }
        
        .typing-dots span:nth-child(1) {
            animation-delay: 0s;
        }
        
        .typing-dots span:nth-child(2) {
            animation-delay: 0.2s;
        }
        
        .typing-dots span:nth-child(3) {
            animation-delay: 0.4s;
        }
        
        @keyframes typingDot {
            0%, 80%, 100% { 
                transform: scale(0.6);
                opacity: 0.6;
            }
            40% { 
                transform: scale(1);
                opacity: 1;
            }
        }
    `;
    
    document.head.appendChild(styleElement);
})();

// Resize observer to handle window size changes
window.addEventListener('resize', function() {
    // Ensure chat layout is updated on window resize
    const userInput = document.getElementById('user-input');
    if (userInput) {
        autoResizeTextarea(userInput);
    }
    
    // Scroll to bottom when window is resized
    scrollChatToBottom();
});

// Make sure the chat container always scrolls to bottom when new content is added
function observeConversationChanges() {
    const conversationContainer = document.querySelector('.conversation-container');
    if (!conversationContainer) return;
    
    // Create a mutation observer to watch for changes
    const observer = new MutationObserver(function(mutations) {
        scrollChatToBottom();
    });
    
    // Configure and start the observer
    observer.observe(conversationContainer, { 
        childList: true, 
        subtree: true,
        characterData: true
    });
}

// Call this function when the component is loaded
document.addEventListener('componentLoaded', function(e) {
    if (e.detail.containerId === 'chat-container') {
        setTimeout(observeConversationChanges, 500);
    }
});


