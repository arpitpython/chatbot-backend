/**
 * Add this initialization code as a new file: init.js
 * Include it in your index.html after all other scripts
 */

// Initialize sidebar and document viewer when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Initialize both fixed toggle buttons and their visibility
    initializeFixedToggles();
    
    // Ensure proper space allocation for the chat container
    setTimeout(adjustChatContainerSpace, 300);
});

// Function to initialize fixed toggle buttons
function initializeFixedToggles() {
    const sidebarCollapsedToggle = document.getElementById('sidebar-collapsed-toggle');
    const documentCollapsedToggle = document.getElementById('document-collapsed-toggle');
    const sidebarContainer = document.getElementById('sidebar-container');
    const documentContainer = document.getElementById('document-container');
    
    // Set initial state of sidebar toggle
    if (sidebarCollapsedToggle && sidebarContainer) {
        if (sidebarContainer.classList.contains('collapsed')) {
            sidebarCollapsedToggle.style.display = 'flex';
        } else {
            sidebarCollapsedToggle.style.display = 'none';
        }
        
        sidebarCollapsedToggle.addEventListener('click', function() {
            toggleSidebar('sidebar-container');
        });
    }
    
    // Set initial state of document toggle
    if (documentCollapsedToggle && documentContainer) {
        if (documentContainer.classList.contains('collapsed')) {
            documentCollapsedToggle.style.display = 'flex';
        } else {
            documentCollapsedToggle.style.display = 'none';
        }
        
        documentCollapsedToggle.addEventListener('click', toggleDocumentViewer);
    }
}

// Observe window resize to adjust layout
window.addEventListener('resize', function() {
    adjustChatContainerSpace();
});


