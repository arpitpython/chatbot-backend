// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize sidebar functionality once sidebar is loaded
    initSidebar();
});

function initSidebar() {
    
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebarCollapsedToggle = document.getElementById('sidebar-collapsed-toggle');
    const sidebar = document.querySelector('.sidebar');
    const sidebarContainer = document.getElementById('sidebar-container');
    const fileUpload = document.getElementById('file-upload');
    const uploadForm = document.getElementById('upload-form');
    const documentList = document.getElementById('document-list');

    if (sidebarToggle && sidebarCollapsedToggle && sidebarContainer) {
        // Toggle sidebar collapse/expand
        sidebarToggle.addEventListener('click', function() {
            sidebarContainer.classList.remove('expanded');
            sidebarContainer.classList.add('collapsed');
            sidebarCollapsedToggle.style.display = 'flex';
        });

        // Toggle sidebar expand when collapsed button is clicked
        sidebarCollapsedToggle.addEventListener('click', function() {
            sidebarContainer.classList.remove('collapsed');
            sidebarContainer.classList.add('expanded');
            sidebarCollapsedToggle.style.display = 'none';
        });
    }

    // Handle file upload
    if (fileUpload && uploadForm) {
        fileUpload.addEventListener('change', function() {
            if (fileUpload.files.length > 0) {
                console.log("function called...");
                const formData = new FormData(uploadForm);
                
                // Add CSRF token
                const csrfToken = window.CSRF_TOKEN || '';
                
                // Upload files
                fetch('/upload_document/', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRFToken': csrfToken
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Refresh document list
                        loadDocuments();
                        
                        // Show success notification
                        showNotification('Documents uploaded successfully!', 'success');
                    } else {
                        showNotification('Error uploading documents: ' + data.error, 'error');
                    }
                })
                .catch(error => {
                    showNotification('Error uploading documents: ' + error, 'error');
                });
            }
        });
    }

    // Initial load of documents
    loadDocuments();
}

// Function to load documents from the server
function loadDocuments() {
    const documentList = document.getElementById('document-list');
    
    if (!documentList) return;
    
    fetch('/get-documents/', {
        method: 'GET',
        headers: {
            'X-CSRFToken': window.CSRF_TOKEN || '',
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.documents && data.documents.length > 0) {
            // Clear document list
            documentList.innerHTML = '';
            
            // Add documents to the list
            data.documents.forEach((document, index) => {
                const docItem = createDocumentItem(document, index === 0);
                documentList.appendChild(docItem);
                
                // Add click event to document item
                docItem.addEventListener('click', function() {
                    // Remove active class from all document items
                    document.querySelectorAll('.document-item').forEach(item => {
                        item.classList.remove('active');
                    });
                    
                    // Add active class to clicked document item
                    docItem.classList.add('active');
                    
                    // Load document in viewer
                    loadDocumentInViewer(document.id);
                });
            });
        } else {
            // No documents found
            documentList.innerHTML = '<div class="no-documents">No documents uploaded yet.</div>';
        }
    })
    .catch(error => {
        console.error('Error loading documents:', error);
        documentList.innerHTML = '<div class="no-documents">Error loading documents.</div>';
    });
}

// Function to create a document item element
function createDocumentItem(document, isActive) {
    const docItem = document.createElement('div');
    docItem.className = `document-item${isActive ? ' active' : ''}`;
    docItem.dataset.documentId = document.id;
    
    // Determine icon based on file extension
    let iconClass = 'fas fa-file';
    const fileName = document.file_name.toLowerCase();
    
    if (fileName.endsWith('.pdf')) {
        iconClass = 'fas fa-file-pdf';
    } else if (fileName.endsWith('.docx') || fileName.endsWith('.doc')) {
        iconClass = 'fas fa-file-word';
    } else if (fileName.endsWith('.txt')) {
        iconClass = 'fas fa-file-alt';
    } else if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
        iconClass = 'fas fa-file-excel';
    }
    
    // Format the date
    const uploadDate = new Date(document.uploaded_at);
    const formattedDate = uploadDate.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    });
    
    docItem.innerHTML = `
        <div class="document-icon">
            <i class="${iconClass}"></i>
        </div>
        <div class="document-info">
            <div class="document-name">${document.file_name}</div>
            <div class="document-date">Uploaded: ${formattedDate}</div>
        </div>
    `;
    
    return docItem;
}

// Function to load a document in the viewer
function loadDocumentInViewer(documentId) {
    const documentContainer = document.getElementById('document-container');
    
    if (!documentContainer) return;
    
    // Show document container if it's collapsed
    documentContainer.classList.remove('collapsed');
    documentContainer.classList.add('expanded');
    
    // Load document content
    fetch(`/get-document/${documentId}/`, {
        method: 'GET',
        headers: {
            'X-CSRFToken': window.CSRF_TOKEN || '',
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update document viewer with content
            const documentViewer = document.getElementById('document-content');
            if (documentViewer) {
                documentViewer.innerHTML = renderDocumentContent(data.document);
            }
            
            // Update document title
            const documentTitle = document.getElementById('document-title');
            if (documentTitle) {
                documentTitle.textContent = data.document.file_name;
            }
        } else {
            showNotification('Error loading document: ' + data.error, 'error');
        }
    })
    .catch(error => {
        showNotification('Error loading document: ' + error, 'error');
    });
}

// Function to show a notification
function showNotification(message, type = 'info') {
    // Check if notifications container exists, create if not
    let notificationsContainer = document.getElementById('notifications-container');
    if (!notificationsContainer) {
        notificationsContainer = document.createElement('div');
        notificationsContainer.id = 'notifications-container';
        document.body.appendChild(notificationsContainer);
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="notification-icon ${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close">×</button>
    `;
    
    // Add to container
    notificationsContainer.appendChild(notification);
    
    // Add close button functionality
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', function() {
        notification.classList.add('fade-out');
        setTimeout(() => {
            notification.remove();
        }, 300);
    });
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.classList.add('fade-out');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 5000);
}

// Helper function to get notification icon based on type
function getNotificationIcon(type) {
    switch (type) {
        case 'success': return 'fas fa-check-circle';
        case 'error': return 'fas fa-exclamation-circle';
        case 'warning': return 'fas fa-exclamation-triangle';
        default: return 'fas fa-info-circle';
    }
}

// Function to render document content based on type
function renderDocumentContent(document) {
    const fileName = document.file_name.toLowerCase();
    
    if (document.content) {
        if (fileName.endsWith('.pdf')) {
            return `<iframe src="data:application/pdf;base64,${document.content}" width="100%" height="100%"></iframe>`;
        } else if (fileName.endsWith('.txt') || fileName.endsWith('.md')) {
            return `<pre>${document.content}</pre>`;
        } else if (fileName.endsWith('.docx') || fileName.endsWith('.doc')) {
            // Display message that preview is not available
            return `<div class="document-preview-message">
                <i class="fas fa-file-word"></i>
                <p>Word document preview is not available. Download to view.</p>
                <button class="download-btn" onclick="downloadDocument('${document.id}')">
                    <i class="fas fa-download"></i> Download
                </button>
            </div>`;
        } else {
            // Generic fallback for other file types
            return `<div class="document-preview-message">
                <i class="fas fa-file"></i>
                <p>Preview not available for this file type. Download to view.</p>
                <button class="download-btn" onclick="downloadDocument('${document.id}')">
                    <i class="fas fa-download"></i> Download
                </button>
            </div>`;
        }
    } else {
        return `<div class="document-preview-message">
            <i class="fas fa-exclamation-circle"></i>
            <p>Document content could not be loaded.</p>
        </div>`;
    }
}

// Function to download a document
function downloadDocument(documentId) {
    window.location.href = `/download-document/${documentId}/`;
}
