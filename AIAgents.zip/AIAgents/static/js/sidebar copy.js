/**
 * Improved sidebar.js with better collapse/expand functionality
 */


function getCsrfToken() {
    return window.CSRF_TOKEN;
}


// Wait for the sidebar component to load
document.addEventListener('componentLoaded', function(e) {
    if (e.detail.containerId === 'sidebar-container') {
        initializeSidebar();
    }
});

/**
 * Initialize sidebar functionality
 */
function initializeSidebar() {
    // Setup toggle functionality
    const sidebarToggle = document.getElementById('sidebar-toggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            toggleSidebar('sidebar-container');
        });
    }
    
    // Setup collapsed toggle button
    const collapsedToggle = document.getElementById('sidebar-collapsed-toggle');
    if (collapsedToggle) {
        collapsedToggle.addEventListener('click', function() {
            toggleSidebar('sidebar-container');
        });
    }
    
    // Setup file upload
    const fileUpload = document.getElementById('file-upload');
    if (fileUpload) {
        fileUpload.addEventListener('change', handleFileUpload);
    }
    
    // Setup document selection
    setupDocumentSelection();
}

/**
 * Toggle sidebar expansion/collapse
 * @param {string} containerId - The ID of the container to toggle
 */
function toggleSidebar(containerId) {
    const sidebarContainer = document.getElementById(containerId);
    const documentContainer = document.getElementById('document-container');
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const collapsedToggle = document.getElementById('sidebar-collapsed-toggle');
    
    if (sidebarContainer.classList.contains('expanded')) {
        // Collapse sidebar
        sidebarContainer.classList.remove('expanded');
        sidebarContainer.classList.add('collapsed');
        
        // Show collapsed toggle button
        if (collapsedToggle) {
            collapsedToggle.style.display = 'flex';
            // Add animation to make it more noticeable
            collapsedToggle.style.animation = 'pulse 2s';
            setTimeout(() => {
                collapsedToggle.style.animation = '';
            }, 2000);
        }
        
        // Update toggle button icon
        if (sidebarToggle) {
            sidebarToggle.innerHTML = '<i class="fas fa-chevron-right"></i>';
            sidebarToggle.setAttribute('title', 'Expand Sidebar');
        }
        
        // Adjust chat container space
        adjustChatContainerSpace();
    } else {
        // Collapse the other sidebar if it's expanded on small screens
        if (containerId === 'sidebar-container' && window.innerWidth < 1200 && 
            documentContainer && documentContainer.classList.contains('expanded')) {
            toggleDocumentViewer();
        }
        
        // Expand this sidebar
        sidebarContainer.classList.remove('collapsed');
        sidebarContainer.classList.add('expanded');
        
        // Hide collapsed toggle button
        if (collapsedToggle) {
            collapsedToggle.style.display = 'none';
        }
        
        // Update toggle button icon
        if (sidebarToggle) {
            sidebarToggle.innerHTML = '<i class="fas fa-chevron-left"></i>';
            sidebarToggle.setAttribute('title', 'Collapse Sidebar');
        }
        
        // Adjust chat container space
        adjustChatContainerSpace();
    }
}

/**
 * Setup document selection functionality
 */
function setupDocumentSelection() {
    const documentItems = document.querySelectorAll('.document-item');
    
    documentItems.forEach(item => {
        const documentId = item.getAttribute('data-document-id');
        const documentName = item.querySelector('.document-name').textContent;
        
        item.addEventListener('click', function() {
            selectDocument(documentId, documentName);
        });
    });
}

/**
 * Select a document from the sidebar
 * @param {string} documentId - The ID of the selected document
 * @param {string} documentName - The name of the selected document
 */
function selectDocument(documentId, documentName) {
    // Update active document in sidebar
    const documentItems = document.querySelectorAll('.document-item');
    documentItems.forEach(item => {
        item.classList.remove('active');
    });
    
    const selectedItem = document.querySelector(`.document-item[data-document-id="${documentId}"]`);
    if (selectedItem) {
        selectedItem.classList.add('active');
    }
    
    // Update document name in chat header
    const currentDocumentName = document.getElementById('current-document-name');
    if (currentDocumentName) {
        currentDocumentName.textContent = documentName;
    }
    
    // Load document content in the document viewer (implement this function)
    if (typeof loadDocumentPreview === 'function') {
        loadDocumentPreview(documentId, documentName);
    }
    
    // Expand the document viewer if it's collapsed
    const documentContainer = document.getElementById('document-container');
    if (documentContainer && documentContainer.classList.contains('collapsed')) {
        toggleDocumentViewer();
    }
    
    // Dispatch an event that a document was selected
    const event = new CustomEvent('documentSelected', {
        detail: {
            documentId: documentId,
            documentName: documentName
        }
    });
    document.dispatchEvent(event);
}

// Handle file upload (optimized)
function handleFileUpload(event) {
    const files = event.target.files;
    if (!files || files.length === 0) {
        showNotification('No files selected.', 'error');
        return;
    }

    console.log('Files selected:', files.length);
    
    // Create FormData object to send multiple files
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
        formData.append('files', files[i]);
        console.log(`File ${i + 1}:`, files[i].name);
    }

    showNotification(`Uploading ${files.length} file(s)...`, 'info');

    async function uploadFiles(formData) {
        try {
            const csrfToken = getCsrfToken();
            const response = await fetch('/upload_document/', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRFToken': csrfToken
                }
            });

            if (!response.ok) {
                throw new Error(`Upload failed: ${response.error.message}`);
            }

            const data = await response.json();
            console.log('Upload successful:', data);
            showNotification('Upload successful!', 'success');
        } catch (error) {
            console.error('Upload error:', error);
            showNotification('Upload failed. Please try again.', 'error');
        }
    }

    uploadFiles(formData);
}


// Make adjustChatContainerSpace function globally available if not already defined
if (typeof window.adjustChatContainerSpace !== 'function') {
    window.adjustChatContainerSpace = function() {
        const chatContainer = document.getElementById('chat-container');
        const sidebarContainer = document.getElementById('sidebar-container');
        const documentContainer = document.getElementById('document-container');
        
        if (!chatContainer || !sidebarContainer || !documentContainer) return;
        
        // Remove existing space classes
        chatContainer.classList.remove('expanded-left');
        chatContainer.classList.remove('expanded-right');
        chatContainer.classList.remove('expanded-both');
        
        // Add appropriate class based on sidebar states
        if (sidebarContainer.classList.contains('collapsed') && 
            documentContainer.classList.contains('collapsed')) {
            chatContainer.classList.add('expanded-both');
        } else if (sidebarContainer.classList.contains('collapsed')) {
            chatContainer.classList.add('expanded-left');
        } else if (documentContainer.classList.contains('collapsed')) {
            chatContainer.classList.add('expanded-right');
        }
    };
}

// Expose the toggleSidebar function globally
window.toggleSidebar = toggleSidebar;

