/**
 * Improved document-viewer.js with better collapse/expand functionality
 */

// Wait for the document viewer component to load
document.addEventListener('componentLoaded', function(e) {
    if (e.detail.containerId === 'document-container') {
        initializeDocumentViewer();
    }
});

/**
 * Initialize document viewer functionality
 */
function initializeDocumentViewer() {
    // Setup toggle functionality
    const documentToggle = document.getElementById('document-toggle');
    if (documentToggle) {
        documentToggle.addEventListener('click', toggleDocumentViewer);
    }
    
    // Setup collapsed toggle button
    const collapsedToggle = document.getElementById('document-collapsed-toggle');
    if (collapsedToggle) {
        collapsedToggle.addEventListener('click', toggleDocumentViewer);
    }
}

/**
 * Toggle document viewer expansion/collapse
 */
function toggleDocumentViewer() {
    const documentContainer = document.getElementById('document-container');
    const sidebarContainer = document.getElementById('sidebar-container');
    const documentToggle = document.getElementById('document-toggle');
    const collapsedToggle = document.getElementById('document-collapsed-toggle');
    
    if (documentContainer.classList.contains('expanded')) {
        // Collapse document viewer
        documentContainer.classList.remove('expanded');
        documentContainer.classList.add('collapsed');
        
        // Show collapsed toggle button
        if (collapsedToggle) {
            collapsedToggle.style.display = 'flex';
            // Add animation to make it more noticeable
            collapsedToggle.style.animation = 'pulse 2s';
            setTimeout(() => {
                collapsedToggle.style.animation = '';
            }, 2000);
        }
        
        // Update toggle icon
        if (documentToggle) {
            documentToggle.innerHTML = '<i class="fas fa-chevron-left"></i>';
            documentToggle.setAttribute('title', 'Expand Document Viewer');
        }
    } else {
        // If sidebar is expanded and screen is small, collapse it first
        if (window.innerWidth < 1200 && sidebarContainer && sidebarContainer.classList.contains('expanded')) {
            if (typeof toggleSidebar === 'function') {
                toggleSidebar('sidebar-container');
            } else if (typeof window.toggleSidebar === 'function') {
                window.toggleSidebar('sidebar-container');
            }
        }
        
        // Expand document viewer
        documentContainer.classList.remove('collapsed');
        documentContainer.classList.add('expanded');
        
        // Hide collapsed toggle button
        if (collapsedToggle) {
            collapsedToggle.style.display = 'none';
        }
        
        // Update toggle icon
        if (documentToggle) {
            documentToggle.innerHTML = '<i class="fas fa-chevron-right"></i>';
            documentToggle.setAttribute('title', 'Collapse Document Viewer');
        }
    }
    
    // Update chat container space
    adjustChatContainerSpace();
}

// Make sure adjustChatContainerSpace function is defined
function adjustChatContainerSpace() {
    const chatContainer = document.getElementById('chat-container');
    const sidebarContainer = document.getElementById('sidebar-container');
    const documentContainer = document.getElementById('document-container');
    
    if (!chatContainer || !sidebarContainer || !documentContainer) return;
    
    // Remove existing space classes
    chatContainer.classList.remove('expanded-left');
    chatContainer.classList.remove('expanded-right');
    chatContainer.classList.remove('expanded-both');
    
    // Add appropriate class based on sidebar states
    if (sidebarContainer.classList.contains('collapsed') && 
        documentContainer.classList.contains('collapsed')) {
        chatContainer.classList.add('expanded-both');
    } else if (sidebarContainer.classList.contains('collapsed')) {
        chatContainer.classList.add('expanded-left');
    } else if (documentContainer.classList.contains('collapsed')) {
        chatContainer.classList.add('expanded-right');
    }
}

// Expose functions globally
window.toggleDocumentViewer = toggleDocumentViewer;
window.adjustChatContainerSpace = adjustChatContainerSpace;