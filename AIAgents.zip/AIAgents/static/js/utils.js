/**
 * Utility functions for the document chatbot application
 */

/**
 * Loads an HTML component into a specified container
 * @param {string} containerId - The ID of the container element
 * @param {string} componentPath - The path to the component HTML file
 */
function loadComponent(containerId, componentPath) {
    const container = document.getElementById(containerId);
    
    if (!container) {
        console.error(`Container with ID ${containerId} not found`);
        return;
    }
    
    fetch(componentPath)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Failed to load component from ${componentPath}`);
            }
            return response.text();
        })
        .then(html => {
            container.innerHTML = html;
            
            // Dispatch a custom event to notify that the component has been loaded
            const event = new CustomEvent('componentLoaded', { 
                detail: { 
                    containerId: containerId,
                    componentPath: componentPath
                } 
            });
            document.dispatchEvent(event);
        })
        .catch(error => {
            console.error(`Error loading component: ${error.message}`);
            container.innerHTML = `<div class="error-message">Failed to load component</div>`;
        });
}

/**
 * Formats a date as a string
 * @param {Date} date - The date to format
 * @param {boolean} includeTime - Whether to include time in the format
 * @returns {string} The formatted date string
 */
function formatDate(date, includeTime = false) {
    if (!(date instanceof Date)) {
        date = new Date(date);
    }
    
    const options = { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric'
    };
    
    if (includeTime) {
        options.hour = '2-digit';
        options.minute = '2-digit';
    }
    
    return date.toLocaleDateString('en-US', options);
}

/**
 * Creates a timestamp for messages
 * @returns {string} The current time formatted as HH:MM AM/PM
 */
function getCurrentTime() {
    const now = new Date();
    return now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
    });
}

/**
 * Truncates text to a specified length and adds ellipsis if needed
 * @param {string} text - The text to truncate
 * @param {number} maxLength - The maximum length
 * @returns {string} The truncated text
 */
function truncateText(text, maxLength) {
    if (text.length <= maxLength) {
        return text;
    }
    return text.substring(0, maxLength) + '...';
}

/**
 * Gets the file icon class based on file extension
 * @param {string} filename - The filename
 * @returns {string} The appropriate Font Awesome icon class
 */
function getFileIconClass(filename) {
    const extension = filename.split('.').pop().toLowerCase();
    
    const iconMap = {
        'pdf': 'fa-file-pdf',
        'doc': 'fa-file-word',
        'docx': 'fa-file-word',
        'xls': 'fa-file-excel',
        'xlsx': 'fa-file-excel',
        'ppt': 'fa-file-powerpoint',
        'pptx': 'fa-file-powerpoint',
        'txt': 'fa-file-alt',
        'csv': 'fa-file-csv',
        'jpg': 'fa-file-image',
        'jpeg': 'fa-file-image',
        'png': 'fa-file-image',
        'gif': 'fa-file-image'
    };
    
    return iconMap[extension] || 'fa-file';
}

/**
 * Creates a unique ID
 * @returns {string} A unique ID
 */
function generateUniqueId() {
    return 'id_' + Math.random().toString(36).substr(2, 9);
}

/**
 * Shows a notification message to the user
 * @param {string} message - The message to display
 * @param {string} type - The type of notification (success, error, warning, info)
 * @param {number} duration - How long to show the notification (in ms)
 */
function showNotification(message, type = 'info', duration = 3000) {
    // Create notification element if it doesn't exist
    let notifications = document.querySelector('.notifications');
    
    if (!notifications) {
        notifications = document.createElement('div');
        notifications.className = 'notifications';
        document.body.appendChild(notifications);
    }
    
    // Create the notification
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Add to container
    notifications.appendChild(notification);
    
    // Show notification with animation
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Remove after duration
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300); // Match the CSS transition duration
    }, duration);
}

/**
 * Gets the appropriate icon for a notification type
 * @param {string} type - The notification type
 * @returns {string} The Font Awesome icon class
 */
function getNotificationIcon(type) {
    const iconMap = {
        'success': 'fa-check-circle',
        'error': 'fa-exclamation-circle',
        'warning': 'fa-exclamation-triangle',
        'info': 'fa-info-circle'
    };
    
    return iconMap[type] || iconMap.info;
}

/**
 * Auto-resize textarea based on content
 * @param {HTMLTextAreaElement} textarea - The textarea element to resize
 */
function autoResizeTextarea(textarea) {
    textarea.style.height = 'auto';
    
    // Limit max height for usability
    const maxHeight = 150;
    const scrollHeight = textarea.scrollHeight;
    
    if (scrollHeight > maxHeight) {
        textarea.style.height = maxHeight + 'px';
        textarea.style.overflowY = 'auto';
    } else {
        textarea.style.height = scrollHeight + 'px';
        textarea.style.overflowY = 'hidden';
    }
}


