from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

import fitz
import pytesseract
from PIL import Image

import base64
import faiss
import numpy as np
import tiktoken
import asyncio
import os
import pickle
import time
import platform
import io
import gzip
import traceback
import psutil
from concurrent.futures import ThreadPoolExecutor, as_completed

from .azure_blob_manager import AzureBlobManager
from openai import AzureOpenAI, OpenAIError

import logging
logger = logging.getLogger(__name__)


class DocumentProcessor:
    def __init__(self, openai_client=None):
        """Initialize the document processor with optional OpenAI client."""
        self.openai_client = openai_client or AzureOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            azure_endpoint=os.getenv("OPENAI_API_BASE"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION")
        )
        
        if platform.system() == 'Windows':
            pytesseract.pytesseract.tesseract_cmd = os.path.join(r'C:\Users\arpit.patel\AppData\Local\Programs\Tesseract-OCR', 'tesseract.exe')
        else:
            pytesseract.pytesseract.tesseract_cmd = '/usr/bin/tesseract'
            os.environ['TESSDATA_PREFIX'] = '/usr/share/tesseract-ocr/4.00/tessdata'
        
        self.chunk_size = 2500
        self.chunk_overlap = 200
        self.batch_size = 50
        self.max_retries = 3
        logger.info("DocumentProcessor Initiated")
        
    def count_tokens(self, text, model="gpt-4o"):
        """Estimate token count for a given text using tiktoken."""
        try:
            encoding = tiktoken.encoding_for_model(model)
            return len(encoding.encode(text))
        except Exception as e:
            logger.warning(f"Error counting tokens: {str(e)}, using fallback estimation")
            return len(text) // 4
    
    def is_scanned_pdf(self, file_data):
        """Check if a PDF is scanned or contains selectable text."""
        try:
            doc = fitz.open(stream=file_data, filetype="pdf")
            total_pages = len(doc)
            sample_pages = min(10, total_pages) 
            
            for i in range(sample_pages):
                text = doc[i].get_text("text").strip()
                if len(text) > 100:  
                    doc.close()
                    return False
            
            doc.close()
            return True
        except Exception as e:
            logger.error(f"Error checking if PDF is scanned: {str(e)}")
            return False
    
    def extract_text_from_pdf(self, file_data):
        """Extract text from a PDF with optimized memory usage and better error handling."""
        try:
            doc = fitz.Document(stream=file_data, filetype="pdf")
            total_pages = len(doc)
            logger.info(f"Processing PDF with {total_pages} pages")
            
            is_scanned = True
            sample_pages = min(10, total_pages)  
            for page_num in range(sample_pages):
                page_text = doc[page_num].get_text("text").strip()
                if len(page_text) > 100: 
                    is_scanned = False
                    break
                    
            text = []
            
            if total_pages <= 50:
                self.batch_size = 20
            elif total_pages <= 200:
                self.batch_size = 10
            else:
                self.batch_size = 5
                
            logger.info(f"Using batch size of {self.batch_size} for PDF extraction")
            
            if is_scanned:
                logger.info("⚠️ Scanned PDF detected. Extracting using OCR...")
                
                ocr_batch_size = max(1, self.batch_size // 4)
                
                try:
                    custom_config = r'--oem 3 --psm 6'
                    
                    for page_num in range(total_pages):
                        if page_num % ocr_batch_size == 0:
                            logger.info(f"OCR processing pages {page_num+1}-{min(page_num+ocr_batch_size, total_pages)} of {total_pages}")
                        
                        try:
                            pix = doc[page_num].get_pixmap(matrix=fitz.Matrix(2, 2))  # Increase resolution for better OCR
                            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                            page_text = pytesseract.image_to_string(img, config=custom_config)
                            text.append(page_text)
                            
                            pix = None
                            img = None
                        except Exception as e:
                            logger.error(f"Error extracting text from page {page_num}: {str(e)}")
                            text.append(f"[ERROR EXTRACTING TEXT FROM PAGE {page_num}]")
                            continue
                except Exception as ocr_error:
                    logger.error(f"OCR setup error: {str(ocr_error)}")
                    logger.info("Falling back to standard text extraction")
                    is_scanned = False
                    
            if not is_scanned:
                for batch_start in range(0, total_pages, self.batch_size):
                    batch_end = min(batch_start + self.batch_size, total_pages)
                    batch_text = []
                    
                    logger.info(f"Processing pages {batch_start+1}-{batch_end} of {total_pages}")
                    
                    for page_num in range(batch_start, batch_end):
                        try:
                            page_text = doc[page_num].get_text(
                                "text", 
                                sort=True, 
                                flags=0  
                            )
                            if not page_text.strip():
                                page_text = doc[page_num].get_text("blocks")
                                if isinstance(page_text, list):
                                    page_text = "\n".join([b[4] for b in page_text if isinstance(b, list) and len(b) > 4 and b[0] == 0])
                                
                            batch_text.append(page_text)
                        except Exception as e:
                            logger.error(f"Error extracting text from page {page_num}: {str(e)}")
                            batch_text.append(f"[ERROR EXTRACTING TEXT FROM PAGE {page_num}]")
                    
                    text.extend(batch_text)
                    
                    batch_text = None
                    
            doc.close()
            doc = None
            
            result = "\n".join(text).strip()
            logger.info(f"Extracted {len(result)} characters from PDF")
            return result
            
        except Exception as e:
            logger.error(f"PDF extraction error: {str(e)}")
            logger.error(traceback.format_exc())
            return f"[ERROR EXTRACTING PDF: {str(e)}]"
    
    def update_chunk_size(self, document_text):
        """Dynamically adjust chunk size based on document length"""
        text_length = len(document_text)
        base_size = self.chunk_size
        
        if text_length < (base_size * 10):
            return base_size
        
        if text_length < (base_size * 50):
            return base_size * 2
        elif text_length < (base_size * 100):
            return base_size * 4
        elif text_length < (base_size * 500):
            return base_size * 6
        else:
            return base_size * 8
    
    def split_documents(self, document_text, source_name):
        """Split a document into chunks with dynamic sizing."""
        self.chunk_size = self.update_chunk_size(document_text)
        self.chunk_overlap = min(int(self.chunk_size * 0.1), 300)  # 10% overlap or max 300 chars
        
        logger.info(f"Using chunk size: {self.chunk_size}, overlap: {self.chunk_overlap} for document: {source_name}")
        
        document = Document(page_content=document_text, metadata={"source": source_name})
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            add_start_index=True,
            strip_whitespace=True
        )
        
        chunks = text_splitter.split_documents([document])
        logger.info(f"Split document into {len(chunks)} chunks")
        
        # Log chunk statistics
        if chunks:
            chunk_sizes = [len(chunk.page_content) for chunk in chunks]
            logger.info(f"Chunk statistics: min={min(chunk_sizes)}, max={max(chunk_sizes)}, avg={sum(chunk_sizes)/len(chunk_sizes):.2f} characters")
        
        return chunks
    
    def generate_embeddings(self, text_chunks):
        """Generate embeddings for text chunks using parallel processing."""
        embeddings = []
        chunk_count = len(text_chunks)
        
        if chunk_count == 0:
            return embeddings
        
        batch_size = 20  
        max_workers = min(4, (chunk_count // 10) + 1)  
        
        def process_batch(batch_chunks):
            batch_embeddings = []
            for chunk in batch_chunks:
                for attempt in range(self.max_retries):
                    try:
                        response = self.openai_client.embeddings.create(
                            model="text-embedding-ada-002",
                            input=[chunk.page_content]
                        )
                        batch_embeddings.append(response.data[0].embedding)
                        break
                    except Exception as e:
                        if attempt < self.max_retries - 1:
                            wait_time = 2 ** attempt
                            logger.warning(f"Embedding API Error: {e}. Retrying in {wait_time}s...")
                            time.sleep(wait_time)
                        else:
                            logger.error(f"Final embedding API Error for chunk: {e}")
                            batch_embeddings.append([0.0] * 1536)  
            return batch_embeddings
        
        batches = []
        for i in range(0, chunk_count, batch_size):
            batch_end = min(i + batch_size, chunk_count)
            batches.append(text_chunks[i:batch_end])
        
        logger.info(f"Processing {len(batches)} batches of embeddings with {max_workers} workers")
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_batch = {executor.submit(process_batch, batch): i for i, batch in enumerate(batches)}
            
            for future in as_completed(future_to_batch):
                batch_idx = future_to_batch[future]
                try:
                    batch_result = future.result()
                    embeddings.extend(batch_result)
                    logger.info(f"Completed batch {batch_idx+1}/{len(batches)} - {len(batch_result)} embeddings")
                except Exception as e:
                    batch_start = batch_idx * batch_size
                    batch_end = min((batch_idx + 1) * batch_size, chunk_count)
                    logger.error(f"Error processing batch {batch_idx+1} (chunks {batch_start}-{batch_end}): {str(e)}")
                    batch_size_actual = batch_end - batch_start
                    embeddings.extend([[0.0] * 1536 for _ in range(batch_size_actual)])
        
        valid_embeddings = [e for e in embeddings if not all(x == 0 for x in e)]
        logger.info(f"Generated {len(valid_embeddings)} valid embeddings out of {chunk_count} chunks")
        
        return embeddings
    
    def _delete_blob_with_retry(self, blob_path, max_retries=3):
        """Delete blob with retry logic."""
        for attempt in range(max_retries):
            try:
                blob_manager = AzureBlobManager(blob_path)
                if blob_manager.delete_blob():
                    logger.info(f"Successfully deleted blob: {blob_path}")
                    return True
                return False
            except Exception as e:
                wait_time = 2 ** attempt
                if attempt < max_retries - 1:
                    logger.warning(f"Error deleting blob {blob_path}: {str(e)}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"Final error deleting blob {blob_path}: {str(e)}")
                    logger.error(traceback.format_exc())
        return False
    
    def _verify_blobs_exist(self, blob_paths):
        """Verify that all specified blobs exist in Azure storage."""
        try:
            for path in blob_paths:
                blob_manager = AzureBlobManager(path)
                if not blob_manager.is_blob_exists():
                    return {
                        'success': False,
                        'error': f"Blob not found: {path}"
                    }
            return {
                'success': True
            }
        except Exception as e:
            logger.error(f"Blob verification error: {str(e)}")
            logger.error(traceback.format_exc())
            return {
                'success': False,
                'error': f"Verification error: {str(e)}"
            }
    
    def load_from_azure_blob(self, document_id):
        """Load processed document data with decompression support"""
        chunks_blob_path = f'docbot_processed/{document_id}_chunks.pkl'
        index_blob_path = f'docbot_processed/{document_id}_index.pkl'
        
        try:
            verification = self._verify_blobs_exist([chunks_blob_path, index_blob_path])
            if not verification['success']:
                logger.error(f"Verification failed: {verification.get('error')}")
                return {
                    "error": f"Document processing data not found: {verification.get('error')}"
                }
            
            chunks_data = None
            chunks_loaded = False
            for attempt in range(self.max_retries):
                try:
                    chunks_blob = AzureBlobManager(chunks_blob_path)
                    chunks_data = chunks_blob.download_from_blob()
                    
                    try:
                        chunks_data = gzip.decompress(chunks_data)
                        logger.info(f"Successfully decompressed chunks data from {len(chunks_data)} bytes")
                    except:
                        logger.info("Chunks data was not compressed or decompression failed")
                    
                    chunks = pickle.loads(chunks_data)
                    chunks_loaded = True
                    logger.info(f"Successfully loaded chunks data: {len(chunks)} chunks")
                    break
                except Exception as e:
                    wait_time = 2 ** attempt
                    if attempt < self.max_retries - 1:
                        logger.warning(f"Error loading chunks from {chunks_blob_path}: {str(e)}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                    else:
                        logger.error(f"Final error loading chunks: {str(e)}")
                        logger.error(traceback.format_exc())
            
            if not chunks_loaded:
                return {"error": "Failed to load document chunks after multiple attempts"}
            
            faiss_index = None
            index_loaded = False
            for attempt in range(self.max_retries):
                try:
                    index_blob = AzureBlobManager(index_blob_path)
                    index_data = index_blob.download_from_blob()
                    
                    try:
                        index_data = gzip.decompress(index_data)
                        logger.info(f"Successfully decompressed index data from {len(index_data)} bytes")
                    except:
                        logger.info("Index data was not compressed or decompression failed")
                    
                    try:
                        index_bytes = io.BytesIO(index_data)
                        faiss_index = faiss.read_index(faiss.IO(index_bytes))
                    except:
                        faiss_index = pickle.loads(index_data)
                        
                    index_loaded = True
                    logger.info(f"Successfully loaded FAISS index with {faiss_index.ntotal} vectors")
                    break
                except Exception as e:
                    wait_time = 2 ** attempt
                    if attempt < self.max_retries - 1:
                        logger.warning(f"Error loading index from {index_blob_path}: {str(e)}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                    else:
                        logger.error(f"Final error loading index: {str(e)}")
                        logger.error(traceback.format_exc())
            
            if not index_loaded:
                return {"error": "Failed to load document index after multiple attempts"}
            
            return {
                'chunks': chunks,
                'faiss_index': faiss_index
            }
        except Exception as e:
            logger.error(f"Unexpected error loading processed data: {str(e)}")
            logger.error(traceback.format_exc())
            return {"error": f"Error loading document data: {str(e)}"}
    
    def query_document(self, document_id, query_text, top_k=4):
        """
        Query a processed document using the stored FAISS index with improved error handling.
        """
        logger.info(f"Querying document {document_id} with: '{query_text}'")
        query_start_time = time.time()
        
        processed_data = self.load_from_azure_blob(document_id)
        if "error" in processed_data:
            logger.error(f"Error loading document data: {processed_data['error']}")
            return {"error": processed_data["error"]}
        
        query_embedding = None
        for attempt in range(self.max_retries):
            try:
                query_response = self.openai_client.embeddings.create(
                    model="text-embedding-ada-002",
                    input=[query_text]
                )
                query_embedding = query_response.data[0].embedding
                break
            except Exception as e:
                wait_time = 2 ** attempt
                if attempt < self.max_retries - 1:
                    logger.warning(f"Query embedding error: {str(e)}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"Final query embedding error: {str(e)}")
                    logger.error(traceback.format_exc())
        
        if query_embedding is None:
            return {"error": "Failed to generate query embedding"}
        
        try:
            faiss_index = processed_data['faiss_index']
            chunks = processed_data['chunks']
            
            if faiss_index.ntotal == 0:
                return {"error": "FAISS index is empty"}
            
            query_vector = np.array([query_embedding], dtype=np.float32)
            distances, indices = faiss_index.search(query_vector, min(top_k, faiss_index.ntotal))
            
            valid_indices = [i for i in indices[0] if i < len(chunks)]
            if not valid_indices:
                return {
                    "matched_chunks": ["No relevant content found in the document."],
                    "distances": []
                }
            
            matched_chunks = [chunks[i]['content'] for i in valid_indices]
            matched_distances = distances[0].tolist()
            
            logger.info(f"Query completed in {time.time() - query_start_time:.2f}s, found {len(matched_chunks)} matching chunks")
            
            return {
                "matched_chunks": matched_chunks,
                "distances": matched_distances
            }
        except Exception as e:
            logger.error(f"Error querying document {document_id}: {str(e)}")
            logger.error(traceback.format_exc())
            return {"error": f"Error searching document: {str(e)}"}
    
    def process_large_document(self, file_data, file_name):
        """Process very large documents by streaming in smaller batches"""
        logger.info(f"Processing large document: {file_name} ({len(file_data)/1024/1024:.2f} MB)")
        start_time = time.time()
        
        try:
            if file_name.lower().endswith('.pdf'):
                doc = fitz.Document(stream=file_data, filetype="pdf")
                total_pages = len(doc)
                
                all_chunks = []
                all_embeddings = []
                batch_size = min(10, max(1, int(50 / (len(file_data) / (1024 * 1024)))))  # Scale batch size inversely with file size
                
                logger.info(f"Processing PDF with {total_pages} pages in batches of {batch_size}")
                
                for batch_start in range(0, total_pages, batch_size):
                    batch_end = min(batch_start + batch_size, total_pages)
                    logger.info(f"Processing pages {batch_start+1}-{batch_end} of {total_pages}")
                    
                    batch_text = []
                    for page_num in range(batch_start, batch_end):
                        try:
                            page_text = doc[page_num].get_text("text")
                            batch_text.append(page_text)
                        except Exception as e:
                            logger.error(f"Error extracting text from page {page_num}: {str(e)}")
                            batch_text.append(f"[ERROR EXTRACTING TEXT FROM PAGE {page_num}]")
                    
                    batch_document_text = "\n".join(batch_text).strip()
                    batch_chunks = self.split_documents(batch_document_text, f"{file_name}_batch_{batch_start}")
                    
                    batch_embeddings = self.generate_embeddings(batch_chunks)
                    
                    all_chunks.extend(batch_chunks)
                    all_embeddings.extend(batch_embeddings)
                    
                    batch_text = None
                    batch_document_text = None
                    batch_chunks = None
                    batch_embeddings = None
                    
                    import gc
                    gc.collect()
                
                doc.close()
                doc = None
                
                faiss_index = self.create_faiss_index(all_embeddings)
                
                processing_time = time.time() - start_time
                logger.info(f"Large document processing completed in {processing_time:.2f}s")
                
                return {
                    'chunks': all_chunks,
                    'faiss_index': faiss_index,
                    'processing_time': processing_time
                }
            else:
                return self.process_document(file_data, file_name)
                
        except Exception as e:
            logger.error(f"Error processing large document {file_name}: {str(e)}")
            logger.error(traceback.format_exc())
            return {
                'chunks': [],
                'faiss_index': None,
                'processing_time': time.time() - start_time,
                'error': str(e)
            }
    
    def create_faiss_index(self, embeddings):
        """Create a memory-efficient FAISS index from embeddings."""
        if not embeddings:
            logger.error("No embeddings found to create FAISS index")
            return None
            
        try:
            embedding_dim = len(embeddings[0])
            logger.info(f"Creating FAISS index with dimension {embedding_dim}")
            
            use_advanced_index = len(embeddings) > 10000
            
            if use_advanced_index:
                quantizer = faiss.IndexFlatL2(embedding_dim)
                
                nlist = min(int(len(embeddings) / 39), 1000) 
                logger.info(f"Using IVF index with {nlist} clusters for {len(embeddings)} vectors")
                index = faiss.IndexIVFFlat(quantizer, embedding_dim, nlist, faiss.METRIC_L2)
                train_size = min(len(embeddings), 100000) 
                training_vectors = np.array(embeddings[:train_size], dtype=np.float32)
                
                logger.info(f"Training IVF index on {train_size} vectors...")
                index.train(training_vectors)
                logger.info("IVF index training complete")
                
                batch_size = 5000  
                for i in range(0, len(embeddings), batch_size):
                    end_idx = min(i + batch_size, len(embeddings))
                    batch = np.array(embeddings[i:end_idx], dtype=np.float32)
                    index.add(batch)
                    if i % 20000 == 0:
                        logger.info(f"Added {i+batch.shape[0]}/{len(embeddings)} vectors to index")
                
                index.nprobe = 10
            else:
                index = faiss.IndexFlatL2(embedding_dim)
                
                batch_size = 5000
                for i in range(0, len(embeddings), batch_size):
                    end_idx = min(i + batch_size, len(embeddings))
                    batch = np.array(embeddings[i:end_idx], dtype=np.float32)
                    index.add(batch)
                    
            logger.info(f"FAISS index created with {index.ntotal} vectors")
            return index
        except Exception as e:
            logger.error(f"Error creating FAISS index: {str(e)}")
            logger.error(traceback.format_exc())
            return None
    
    def process_document(self, file_data, file_name):
        """
        Process a document with enhanced error handling and diagnostics
        """
        start_time = time.time()
        file_size_mb = len(file_data)/1024/1024
        logger.info(f"Starting to process document: {file_name} ({file_size_mb:.2f} MB)")
        
        logger.info(f"System: {platform.system()} {platform.release()} ({platform.machine()})")
        
        try:
            mem = psutil.virtual_memory()
            logger.info(f"Memory: {mem.available/1024/1024:.2f}MB available of {mem.total/1024/1024:.2f}MB total")
        except:
            logger.info("Unable to get memory information")
        
        try:
            extraction_start = time.time()
            if file_name.lower().endswith('.pdf'):
                document_text = self.extract_text_from_pdf(file_data)
                logger.info(f"Text extraction completed in {time.time() - extraction_start:.2f}s, extracted {len(document_text)} characters")
            else:
                document_text = file_data.decode('utf-8', errors='ignore')
                logger.info(f"Text decoding completed in {time.time() - extraction_start:.2f}s, decoded {len(document_text)} characters")
            
            if not document_text or len(document_text.strip()) < 100:
                logger.warning(f"Document {file_name} contains little text: {len(document_text)} characters")
            
            chunking_start = time.time()
            chunks = self.split_documents(document_text, file_name)
            chunk_time = time.time() - chunking_start
            logger.info(f"Document split into {len(chunks)} chunks in {chunk_time:.2f}s")
            
            if not chunks:
                logger.error(f"Failed to create chunks from document: {file_name}")
                return {
                    'chunks': [],
                    'faiss_index': None,
                    'processing_time': time.time() - start_time,
                    'error': 'Failed to create chunks from document'
                }
            
            embedding_start = time.time()
            embeddings = self.generate_embeddings(chunks)
            embedding_time = time.time() - embedding_start
            
            valid_embeddings = [e for e in embeddings if not all(x == 0 for x in e)]
            logger.info(f"Generated {len(valid_embeddings)} valid embeddings of {len(chunks)} chunks in {embedding_time:.2f}s")
            
            if len(valid_embeddings) < len(chunks):
                logger.warning(f"Some embeddings ({len(chunks) - len(valid_embeddings)}) failed to generate properly")
            
            index_start = time.time()
            try:
                before_mem = psutil.virtual_memory().available
            except:
                before_mem = 0
                
            faiss_index = self.create_faiss_index(valid_embeddings)
            
            try:
                after_mem = psutil.virtual_memory().available
                mem_used = (before_mem - after_mem)/1024/1024
            except:
                mem_used = 0
                
            index_time = time.time() - index_start
            
            logger.info(f"FAISS index created in {index_time:.2f}s, memory used: {mem_used:.2f}MB")
            
            processing_time = time.time() - start_time
            logger.info(f"Document processing completed in {processing_time:.2f}s")
            
            return {
                'chunks': chunks,
                'faiss_index': faiss_index,
                'processing_time': processing_time,
                'stats': {
                    'document_size': len(file_data),
                    'text_length': len(document_text),
                    'chunk_count': len(chunks),
                    'embedding_count': len(valid_embeddings),
                    'extraction_time': time.time() - extraction_start,
                    'chunking_time': chunk_time,
                    'embedding_time': embedding_time,
                    'index_time': index_time
                }
            }
        except MemoryError as me:
            logger.critical(f"Memory error processing document {file_name}: {str(me)}")
            try:
                mem = psutil.virtual_memory()
                logger.critical(f"Memory stats at failure: {mem.available/1024/1024:.2f}MB available, {mem.percent}% used")
            except:
                logger.critical("Unable to get memory information after error")
                
            return {
                'chunks': [],
                'faiss_index': None,
                'processing_time': time.time() - start_time,
                'error': f"Out of memory error: {str(me)}"
            }
        except Exception as e:
            logger.error(f"Error processing document {file_name}: {str(e)}")
            logger.error(traceback.format_exc())
            processing_time = time.time() - start_time
            return {
                'chunks': [],
                'faiss_index': None,
                'processing_time': processing_time,
                'error': str(e)
            }
    
    def serialize_processing_results(self, results):
        """Serialize the processing results with compression for large files"""
        try:
            chunks = results.get('chunks', [])
            faiss_index = results.get('faiss_index')
            
            if not chunks or faiss_index is None:
                error = results.get('error', 'Unknown error during processing')
                logger.error(f"Cannot serialize incomplete processing results: {error}")
                return None
            
            chunks_data = [
                {
                    'content': chunk.page_content,
                    'metadata': chunk.metadata
                } for chunk in chunks
            ]
            
            chunks_pickle = pickle.dumps(chunks_data, protocol=4)
            
            try:
                faiss_index_bytes = io.BytesIO()
                faiss.write_index(faiss_index, faiss.IO(faiss_index_bytes))
                faiss_index_data = faiss_index_bytes.getvalue()
            except:
                faiss_index_data = pickle.dumps(faiss_index, protocol=4)
            
            chunks_compressed = gzip.compress(chunks_pickle)
            faiss_compressed = gzip.compress(faiss_index_data)
            
            logger.info(f"Serialized chunks: {len(chunks_pickle):,} bytes → {len(chunks_compressed):,} bytes compressed")
            logger.info(f"Serialized FAISS: {len(faiss_index_data):,} bytes → {len(faiss_compressed):,} bytes compressed")
            
            return {
                'chunks_data': chunks_compressed,
                'faiss_index_data': faiss_compressed,
                'compressed': True
            }
        except Exception as e:
            logger.error(f"Error serializing processing results: {str(e)}")
            logger.error(traceback.format_exc())
            return None
    
    def save_to_azure_blob(self, document_id, serialized_data):
        """Save large data to Azure Blob Storage using chunked upload"""
        if not serialized_data:
            logger.error(f"Cannot save empty serialized data for document {document_id}")
            return {
                'success': False,
                'error': 'No serialized data available to save'
            }
        
        chunks_blob_path = f'docbot_processed/{document_id}_chunks.pkl'
        index_blob_path = f'docbot_processed/{document_id}_index.pkl'
        
        try:
            logger.info(f"Uploading chunks data ({len(serialized_data['chunks_data']):,} bytes) to {chunks_blob_path}")
            chunks_blob = AzureBlobManager(chunks_blob_path)
            
            if len(serialized_data['chunks_data']) > 8 * 1024 * 1024: 
                block_size = 4 * 1024 * 1024
                blocks = []
                
                chunks_data = serialized_data['chunks_data']
                for i in range(0, len(chunks_data), block_size):
                    block_id = f"block-{i:08d}"
                    block_data = chunks_data[i:i+block_size]
                    block_id_bytes = block_id.encode('utf-8')
                    block_id_base64 = base64.b64encode(block_id_bytes).decode('utf-8')
                    
                    chunks_blob.stage_block(block_id_base64, block_data)
                    blocks.append(block_id_base64)
                    
                    logger.info(f"Staged block {len(blocks)} for chunks data ({len(block_data):,} bytes)")
                
                chunks_blob.commit_block_list(blocks)
                logger.info(f"Committed {len(blocks)} blocks for chunks data")
            else:
                chunks_blob.upload_to_blob(serialized_data['chunks_data'])
                
            logger.info(f"Uploading index data ({len(serialized_data['faiss_index_data']):,} bytes) to {index_blob_path}")
            index_blob = AzureBlobManager(index_blob_path)
            
            if len(serialized_data['faiss_index_data']) > 8 * 1024 * 1024:  
                block_size = 4 * 1024 * 1024
                blocks = []
                
                index_data = serialized_data['faiss_index_data']
                for i in range(0, len(index_data), block_size):
                    block_id = f"block-{i:08d}"
                    block_data = index_data[i:i+block_size]
                    block_id_bytes = block_id.encode('utf-8')
                    block_id_base64 = base64.b64encode(block_id_bytes).decode('utf-8')
                    
                    index_blob.stage_block(block_id_base64, block_data)
                    blocks.append(block_id_base64)
                    
                    logger.info(f"Staged block {len(blocks)} for index data ({len(block_data):,} bytes)")
                
                index_blob.commit_block_list(blocks)
                logger.info(f"Committed {len(blocks)} blocks for index data")
            else:
                index_blob.upload_to_blob(serialized_data['faiss_index_data'])
                
            verification = self._verify_blobs_exist([chunks_blob_path, index_blob_path])
            if verification['success']:
                logger.info(f"Successfully saved document {document_id} to blob storage")
                return {
                    'success': True,
                    'chunks_path': chunks_blob_path,
                    'index_path': index_blob_path
                }
            else:
                logger.error(f"Verification failed for document {document_id}: {verification.get('error')}")
                chunks_blob.delete_blob()
                index_blob.delete_blob()
                
                return {
                    'success': False,
                    'error': f"Verification failed: {verification.get('error')}"
                }
                
        except Exception as e:
            logger.error(f"Error saving document {document_id} to blob storage: {str(e)}")
            logger.error(traceback.format_exc())
            
            try:
                AzureBlobManager(chunks_blob_path).delete_blob()
                AzureBlobManager(index_blob_path).delete_blob()
            except:
                logger.info("Failed to clean up partial uploads")
                
            return {
                'success': False,
                'error': f'Azure storage error: {str(e)}'
            }
    
    def _save_blob_with_retry(self, blob_path, data, max_retries=3):
        """Save blob with retry logic and exponential backoff."""
        for attempt in range(max_retries):
            try:
                blob_manager = AzureBlobManager(blob_path)
                
                if len(data) > 8 * 1024 * 1024: 
                    block_size = 4 * 1024 * 1024
                    blocks = []
                    
                    for i in range(0, len(data), block_size):
                        block_id = f"block-{i:08d}"
                        block_data = data[i:i+block_size]
                        block_id_bytes = block_id.encode('utf-8')
                        block_id_base64 = base64.b64encode(block_id_bytes).decode('utf-8')
                        
                        blob_manager.stage_block(block_id_base64, block_data)
                        blocks.append(block_id_base64)
                        
                        logger.info(f"Staged block {len(blocks)} for {blob_path} ({len(block_data):,} bytes)")
                    
                    blob_manager.commit_block_list(blocks)
                    logger.info(f"Committed {len(blocks)} blocks for {blob_path}")
                else:
                    blob_manager.upload_to_blob(data)
                
                logger.info(f"Successfully saved blob: {blob_path}")
                return True
            except Exception as e:
                wait_time = 2 ** attempt
                if attempt < max_retries - 1:
                    logger.warning(f"Error saving blob {blob_path}: {str(e)}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"Final error saving blob {blob_path}: {str(e)}")
                    logger.error(traceback.format_exc())
        return False
    
    def _delete_blob_with_retry(self, blob_path, max_retries=3):
        """Delete blob with retry logic."""
        for attempt in range(max_retries):
            try:
                blob_manager = AzureBlobManager(blob_path)
                if blob_manager.delete_blob():
                    logger.info(f"Successfully deleted blob: {blob_path}")
                    return True
                return False
            except Exception as e:
                wait_time = 2 ** attempt
                if attempt < max_retries - 1:
                    logger.warning(f"Error deleting blob {blob_path}: {str(e)}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"Final error deleting blob {blob_path}: {str(e)}")
                    logger.error(traceback.format_exc())
        return False
    
    def _verify_blobs_exist(self, blob_paths):
        """Verify that all specified blobs exist in Azure storage."""
        try:
            for path in blob_paths:
                blob_manager = AzureBlobManager(path)
                if not blob_manager.is_blob_exists():
                    return {
                        'success': False,
                        'error': f"Blob not found: {path}"
                    }
            return {
                'success': True
            }
        except Exception as e:
            logger.error(f"Blob verification error: {str(e)}")
            logger.error(traceback.format_exc())
            return {
                'success': False,
                'error': f"Verification error: {str(e)}"
            }
    
    def load_from_azure_blob(self, document_id):
        """Load processed document data with decompression support"""
        chunks_blob_path = f'docbot_processed/{document_id}_chunks.pkl'
        index_blob_path = f'docbot_processed/{document_id}_index.pkl'
        
        try:
            verification = self._verify_blobs_exist([chunks_blob_path, index_blob_path])
            if not verification['success']:
                logger.error(f"Verification failed: {verification.get('error')}")
                return {
                    "error": f"Document processing data not found: {verification.get('error')}"
                }
            
            chunks_data = None
            chunks_loaded = False
            for attempt in range(self.max_retries):
                try:
                    chunks_blob = AzureBlobManager(chunks_blob_path)
                    chunks_data = chunks_blob.download_from_blob()
                    
                    try:
                        chunks_data = gzip.decompress(chunks_data)
                        logger.info(f"Successfully decompressed chunks data from {len(chunks_data)} bytes")
                    except:
                        logger.info("Chunks data was not compressed or decompression failed")
                    
                    chunks = pickle.loads(chunks_data)
                    chunks_loaded = True
                    logger.info(f"Successfully loaded chunks data: {len(chunks)} chunks")
                    break
                except Exception as e:
                    wait_time = 2 ** attempt
                    if attempt < self.max_retries - 1:
                        logger.warning(f"Error loading chunks from {chunks_blob_path}: {str(e)}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                    else:
                        logger.error(f"Final error loading chunks: {str(e)}")
                        logger.error(traceback.format_exc())
            
            if not chunks_loaded:
                return {"error": "Failed to load document chunks after multiple attempts"}
            
            faiss_index = None
            index_loaded = False
            for attempt in range(self.max_retries):
                try:
                    index_blob = AzureBlobManager(index_blob_path)
                    index_data = index_blob.download_from_blob()
                    
                    try:
                        index_data = gzip.decompress(index_data)
                        logger.info(f"Successfully decompressed index data from {len(index_data)} bytes")
                    except:
                        logger.info("Index data was not compressed or decompression failed")
                    
                    try:
                        index_bytes = io.BytesIO(index_data)
                        faiss_index = faiss.read_index(faiss.IO(index_bytes))
                    except:
                        faiss_index = pickle.loads(index_data)
                        
                    index_loaded = True
                    logger.info(f"Successfully loaded FAISS index with {faiss_index.ntotal} vectors")
                    break
                except Exception as e:
                    wait_time = 2 ** attempt
                    if attempt < self.max_retries - 1:
                        logger.warning(f"Error loading index from {index_blob_path}: {str(e)}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                    else:
                        logger.error(f"Final error loading index: {str(e)}")
                        logger.error(traceback.format_exc())
            
            if not index_loaded:
                return {"error": "Failed to load document index after multiple attempts"}
            
            return {
                'chunks': chunks,
                'faiss_index': faiss_index
            }
        except Exception as e:
            logger.error(f"Unexpected error loading processed data: {str(e)}")
            logger.error(traceback.format_exc())
            return {"error": f"Error loading document data: {str(e)}"}
    
    def query_document(self, document_id, query_text, top_k=4):
        """
        Query a processed document using the stored FAISS index with improved error handling.
        """
        logger.info(f"Querying document {document_id} with: '{query_text}'")
        query_start_time = time.time()
        
        processed_data = self.load_from_azure_blob(document_id)
        if "error" in processed_data:
            logger.error(f"Error loading document data: {processed_data['error']}")
            return {"error": processed_data["error"]}
        
        query_embedding = None
        for attempt in range(self.max_retries):
            try:
                query_response = self.openai_client.embeddings.create(
                    model="text-embedding-ada-002",
                    input=[query_text]
                )
                query_embedding = query_response.data[0].embedding
                break
            except Exception as e:
                wait_time = 2 ** attempt
                if attempt < self.max_retries - 1:
                    logger.warning(f"Query embedding error: {str(e)}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"Final query embedding error: {str(e)}")
                    logger.error(traceback.format_exc())
        
        if query_embedding is None:
            return {"error": "Failed to generate query embedding"}
        
        try:
            faiss_index = processed_data['faiss_index']
            chunks = processed_data['chunks']
            
            if faiss_index.ntotal == 0:
                return {"error": "FAISS index is empty"}
            
            query_vector = np.array([query_embedding], dtype=np.float32)
            distances, indices = faiss_index.search(query_vector, min(top_k, faiss_index.ntotal))
            
            valid_indices = [i for i in indices[0] if i < len(chunks)]
            if not valid_indices:
                return {
                    "matched_chunks": ["No relevant content found in the document."],
                    "distances": []
                }
            
            matched_chunks = [chunks[i]['content'] for i in valid_indices]
            matched_distances = distances[0].tolist()
            
            logger.info(f"Query completed in {time.time() - query_start_time:.2f}s, found {len(matched_chunks)} matching chunks")
            
            return {
                "matched_chunks": matched_chunks,
                "distances": matched_distances
            }
        except Exception as e:
            logger.error(f"Error querying document {document_id}: {str(e)}")
            logger.error(traceback.format_exc())
            return {"error": f"Error searching document: {str(e)}"}
    
    def process_large_document(self, file_data, file_name):
        """Process very large documents by streaming in smaller batches"""
        logger.info(f"Processing large document: {file_name} ({len(file_data)/1024/1024:.2f} MB)")
        start_time = time.time()
        
        try:
            if file_name.lower().endswith('.pdf'):
                doc = fitz.Document(stream=file_data, filetype="pdf")
                total_pages = len(doc)
                
                all_chunks = []
                all_embeddings = []
                batch_size = min(10, max(1, int(50 / (len(file_data) / (1024 * 1024)))))  
                
                logger.info(f"Processing PDF with {total_pages} pages in batches of {batch_size}")
                
                for batch_start in range(0, total_pages, batch_size):
                    batch_end = min(batch_start + batch_size, total_pages)
                    logger.info(f"Processing pages {batch_start+1}-{batch_end} of {total_pages}")
                    
                    batch_text = []
                    for page_num in range(batch_start, batch_end):
                        try:
                            page_text = doc[page_num].get_text("text")
                            batch_text.append(page_text)
                        except Exception as e:
                            logger.error(f"Error extracting text from page {page_num}: {str(e)}")
                            batch_text.append(f"[ERROR EXTRACTING TEXT FROM PAGE {page_num}]")
                    
                    batch_document_text = "\n".join(batch_text).strip()
                    batch_chunks = self.split_documents(batch_document_text, f"{file_name}_batch_{batch_start}")
                    batch_embeddings = self.generate_embeddings(batch_chunks)
                    all_chunks.extend(batch_chunks)
                    all_embeddings.extend(batch_embeddings)
                    
                    batch_text = None
                    batch_document_text = None
                    batch_chunks = None
                    batch_embeddings = None
                    
                    import gc
                    gc.collect()
                
                doc.close()
                doc = None
                faiss_index = self.create_faiss_index(all_embeddings)
                processing_time = time.time() - start_time
                logger.info(f"Large document processing completed in {processing_time:.2f}s")
                
                return {
                    'chunks': all_chunks,
                    'faiss_index': faiss_index,
                    'processing_time': processing_time
                }
            else:
                return self.process_document(file_data, file_name)
                
        except Exception as e:
            logger.error(f"Error processing large document {file_name}: {str(e)}")
            logger.error(traceback.format_exc())
            return {
                'chunks': [],
                'faiss_index': None,
                'processing_time': time.time() - start_time,
                'error': str(e)
            }