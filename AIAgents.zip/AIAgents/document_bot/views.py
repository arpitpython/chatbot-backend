# Django
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.db.models import Max, Min, Count
from django.views.decorators.csrf import ensure_csrf_cookie, csrf_protect, csrf_exempt
from django.views.decorators.http import require_http_methods
from django.middleware.csrf import get_token
from django.utils.text import Truncator
from django.utils import timezone
from django.db import transaction
from django.core.exceptions import ValidationError
from docx import Document as wordDocument

# rest framework
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny

# other 
from dotenv import load_dotenv, find_dotenv
from uuid import UUID
from datetime import datetime
from datetime import timezone as datetime_timezone
import time
import pytz
import platform
import json
import urllib.parse
import base64
import mimetypes

import logging
logger = logging.getLogger(__name__)

# same project files
from .serializers import LAChatMessageSerializer
from .azure_blob_manager import AzureBlobManager
from .bot_utilities import *
from .models import *
from .serializers import *
from .utilities import *
from .document_processor import *


load_dotenv(find_dotenv())


def running_locally():    
    return True if platform.system() == "Windows" else False


@csrf_exempt
def get_authentication_details(request):
    """
    Extract authentication details from various possible sources in the request
    """
    if hasattr(request, 'data') and isinstance(request.data, dict) and request.data:
        user_id = request.data.get('user_id') or request.data.get('userId')
        login_key = request.data.get('login_key') or request.data.get('loginKey')
        login_email = request.data.get('login_email') or request.data.get('user_email') or request.data.get('email') or request.data.get('loginEmail')
        
        return {
            'user_id': user_id,
            'login_key': login_key,
            'login_email': login_email
        }
    
    query_dict = getattr(request, 'query_params', request.GET)
    
    user_id = query_dict.get('user_id')
    login_key = query_dict.get('login_key')
    login_email = query_dict.get('login_email') or query_dict.get('user_email') or query_dict.get('email') or query_dict.get('loginEmail')
    
    return {
        'user_id': user_id,
        'login_key': login_key,
        'login_email': login_email
    }
    

# Automation User Request
@api_view(['GET'])
@require_http_methods(["GET", "OPTIONS"])
@csrf_exempt
@permission_classes([AllowAny])
def get_automation_users(request):
    """
    Get automation user - trigger from automation app.

    Args:
        user_id integer : user id
        login_key str : login key or session id

    Returns:
        success (bool) : true if user found else error
        login_user dict : login user data
        status : status code
    """
    
    auth = get_authentication_details(request)
    user_id = auth.get('user_id')
    login_key = auth.get('login_key')
        
    if not user_id or not login_key:
        logger.error(f"User Id and User Key required.")
        return Response({
            "success": False,
            "error": "User Id and User Key required.",
            "message": "User Id and User Key required."
        }, status=status.HTTP_401_UNAUTHORIZED)

    user_data = AutomationUserTracking.objects.filter(user_id=user_id, login_key=login_key)
    if not user_data.exists():
        logger.error(f"User not found or Invalid token")
        return Response({
            'success': False,
            'message': 'User not found or Invalid token',
            'error': {
                'code': 'AUTH_001',
                'message': 'User not found or Invalid token',
                'details': 'Authentication failed. Please login again.'
            }
        }, status=401)
        
    # validate session
    user = user_data.order_by('-login_time').first()
    session_time = user.login_time.replace(tzinfo=datetime_timezone.utc)
    current_time = datetime.now(datetime_timezone.utc)

    serializer = AutomationUserTrackingSerializer(user)
    request.session['user_data'] = serializer.data
    request.session.modified = True
    login_user = serializer.data
    
    response = Response({
        "status":"success",
        'success': True,
        'login_user': login_user,
        'user_data': {
            'user': user.user_id,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'email': user.email,
            'role': user.role,
            'session_time_out':user.session_time_out,
        },
    }, status=status.HTTP_200_OK)
    
    return response


@csrf_exempt
def load_document_bot(request):
    template = 'index.html'
    documents = UploadedDocument.objects.all()
    document_serializer = DocumentSerializer(documents, many=True)
    document_data = document_serializer.data
    context = {
        'documents': document_data
    }
    return render(request, template_name=template, context=context)


@csrf_exempt
def get_csrf_token(request):
    """
    Endpoint that sets and returns the CSRF token.
    """
    token = get_token(request)
    response = JsonResponse({"csrfToken": token})
    
    # Set consistent cookie settings
    response.set_cookie(
        'csrftoken',
        token,
        max_age=3600 * 24 * 7,
        path='/',
        secure=True, 
        httponly=False,
        samesite='None'
    )
    
    response["Access-Control-Allow-Origin"] = "https://chatflowapp-dev.aixsol.com"
    response["Access-Control-Allow-Credentials"] = "true"
    return response

@api_view(['GET'])
@csrf_exempt
def get_documents(request):
    """
    API endpoint to get all documents
    """

    auth = get_authentication_details(request)
    login_email = auth.get('login_email')    
    if not login_email:
        return JsonResponse({
            "success": False,
            "error": "Login Required" 
        }, status=status.HTTP_401_UNAUTHORIZED)

    document_data = document_list(login_email)
    return JsonResponse({
        "success": True,
        "documents": document_data,
    })


@api_view(['POST'])
@csrf_exempt
def upload_document(request):
    """
    API endpoint to upload a document with transaction-like behavior
    """
    temp_blob_path = None
    start_time = time.time()
    
    try:
        auth = get_authentication_details(request)
        user_email = auth.get('login_email')
        if not user_email:
            return Response({
                "success": False,
                "error": "Session Expired. Login Required",
                "message": "Session Expired. Login Required",
            }, status=status.HTTP_401_UNAUTHORIZED)
            
        uploaded_file = request.FILES.get('file')
        if not uploaded_file:
            return JsonResponse({
                'success': False,
                'message': 'No file uploaded.'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        bot_type = request.data.get('task_type')
        file_name = uploaded_file.name
        file_type = uploaded_file.content_type
        file_size = round((uploaded_file.size / 1000000), 2)
        file_data = uploaded_file.read()
        err_remarks = None
        if file_size > 10:
            err_remarks = f"The maximum allowed file size is 10 MB. Your file size is {file_size} MB."
            return Response({
                "success": False,
                "error": {err_remarks},
                "message": {err_remarks},
            }, status=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE)
    
        if "pdf" in str(file_type).lower():
            doc = fitz.open(stream=file_data, filetype=file_type)
            num_pages = doc.page_count              
            if num_pages > 300:
                err_remarks = f"The maximum allowed file size is 300 pages. Your file contains {num_pages} pages."
                
        if "word" in str(file_type).lower():
            read_document = extract_text_from_docx(file_data)
            token_count = count_tokens(read_document)
            if token_count > 125000:
                err_remarks = f"The document you uploaded is too large to process. Please try uploading a smaller file."
        
        if str(file_type).lower() == 'text/plain':
            read_document = file_data.decode("utf-8")
            token_count = count_tokens(read_document)
            if token_count > 125000:
                err_remarks = f"The document you uploaded is too large to process. Please try uploading a smaller file."
        
        if err_remarks:
            return Response({
                "success": False,
                "error": {err_remarks},
                "message": {err_remarks},
            }, status=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE)
        
        temp_blob_path = f'docbot_files_temp/{file_name}_{int(time.time())}'
        azure_blob = AzureBlobManager(temp_blob_path)
        azure_blob.upload_to_blob(file_data)
                
        processing_status = "success"
        processing_message = f"{bot_type}"
        processing_results = None
        
        if bot_type == "document":
            try:
                processor = DocumentProcessor()
                processing_results = processor.process_document(file_data, file_name)
                
                if 'error' in processing_results:
                    if temp_blob_path:
                        AzureBlobManager(temp_blob_path).delete_blob()
                    return JsonResponse({
                        'success': False,
                        'error': f'Document upload failed: {processing_results["error"]}',
                        'message': f'Document upload failed: {processing_results["error"]}',
                    }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                
                serialized_data = processor.serialize_processing_results(processing_results)
                if not serialized_data:
                    if temp_blob_path:
                        AzureBlobManager(temp_blob_path).delete_blob()
                    return JsonResponse({
                        'success': False,
                        'error': 'Failed to process document content.',
                        'message': 'Failed to process document content.',
                    }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                
                document = UploadedDocument.objects.create(
                    file_name=file_name,
                    file_type=file_type,
                    file_size=file_size,
                    file_url=azure_blob.blob.primary_endpoint,
                    azure_blob_path=temp_blob_path,
                    bot_type=bot_type,
                    uploaded_by=user_email
                )
                
                blob_save_result = processor.save_to_azure_blob(str(document.id), serialized_data)
                
                if not blob_save_result['success']:
                    if temp_blob_path:
                        AzureBlobManager(temp_blob_path).delete_blob()
                    document.delete()
                    return JsonResponse({
                        'success': False,
                        'error': f'Failed to save document data: {blob_save_result["error"]}',
                        'message': f'Failed to save document data: {blob_save_result["error"]}',
                    }, status=500)
                
                permanent_blob_path = f'docbot_files/{document.id}_{file_name}'                
                permanent_blob = AzureBlobManager(permanent_blob_path)
                temp_data = azure_blob.download_from_blob()
                permanent_blob.upload_to_blob(temp_data)
                
                azure_blob.delete_blob()                
                document.azure_blob_path = permanent_blob_path
                document.save()
                
                file_url = permanent_blob.generate_blob_sas_url()
                
                processing_message = f"Document processed successfully in {processing_results['processing_time']:.2f} seconds"
            except Exception as processing_error:
                if temp_blob_path:
                    AzureBlobManager(temp_blob_path).delete_blob()
                processing_status = "error"
                processing_message = f"Document processing failed: {str(processing_error)}"
                logger.error(f"Document processing error: {str(processing_error)}")
                return JsonResponse({
                    'success': False,
                    'error': processing_message,
                    'message': processing_message,
                }, status=500)
        else:
            document = UploadedDocument.objects.create(
                file_name=file_name,
                file_type=file_type,
                file_size=file_size,
                file_url=azure_blob.blob.primary_endpoint,
                azure_blob_path=temp_blob_path,
                bot_type=bot_type,
                uploaded_by=user_email
            )
            
            permanent_blob_path = f'docbot_files/{document.id}_{file_name}'
            permanent_blob = AzureBlobManager(permanent_blob_path)
            temp_data = azure_blob.download_from_blob()
            permanent_blob.upload_to_blob(temp_data)
            
            azure_blob.delete_blob()
            
            document.azure_blob_path = permanent_blob_path
            document.save()            
            file_url = permanent_blob.generate_blob_sas_url()
        
        end_time = time.time()
        time_taken = end_time - start_time
        print(timedelta(seconds=int(time_taken)))
        
        return JsonResponse({
            'success': True,
            'message': 'Document uploaded successfully.',
            'id': document.id,
            'name': document.file_name,
            'type': document.file_type,
            'size': document.file_size,
            'created_at': document.created_at,
            'url': file_url,
            'processing': {
                'status': processing_status,
                'message': processing_message
            }
        }, status=201)
        
    except Exception as e:
        if temp_blob_path:
            try:
                AzureBlobManager(temp_blob_path).delete_blob()
            except:
                pass
        
        logger.error(f"Error in upload_document: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': f'Document Upload Failed: {str(e)}',
            'message': f'Document Upload Failed: {str(e)}'
        }, status=500)
        

def process_document_background(document_id, file_data, file_name):
    """Background processing for uploaded documents"""
    try:
        # Get document from database
        document = UploadedDocument.objects.get(id=document_id)
        
        # Process document
        processor = DocumentProcessor()
        processing_results = processor.process_document(file_data, file_name)
        serialized_data = processor.serialize_processing_results(processing_results)
        processor.save_to_azure_blob(str(document_id), serialized_data)
        
        # Update document status
        document.processing_status = 'completed'
        document.processing_time = processing_results['processing_time']
        document.save()
        
        logger.info(f"Background processing completed for document {document_id} in {processing_results['processing_time']:.2f} seconds")
    except Exception as e:
        error_message = str(e)
        logger.error(f"Background processing error for document {document_id}: {error_message}")
        
        # Update document with error status
        try:
            document = UploadedDocument.objects.get(id=document_id)
            document.processing_status = 'error'
            document.processing_error = error_message[:500]  # Limit error message length
            document.save()
        except Exception as inner_e:
            logger.error(f"Failed to update document status: {str(inner_e)}")
            
        

@api_view(['DELETE'])
@csrf_exempt
def delete_document(request, documentId):
    document = UploadedDocument.objects.get(id=documentId)
    document.is_deleted = True
    document.save()
    
    LAChatMessage.objects.filter(document=document).update(delete_status=True) 
    
    azure_document = AzureBlobManager(document.azure_blob_path)
    azure_document.delete_blob()

    return JsonResponse({
        'success': True,
        'message': 'Document deleted successfully.',
    }, status=200)
    

@api_view(['POST'])    
@csrf_exempt
def process_message(request):
    """
    Process message with optimized document handling
    """
    process_start_time = time.time()
    
    try:
        session_status = verify_session_timeout(request)
        if not session_status:
            return Response({
                'success': False,
                'message': 'Your session has timed out. Please login again to continue.',
                'error': {
                    'summary': 'Session expired',
                    'details': 'Your session has timed out. Please login again to continue.',
                    'code': 'AUTH_EXPIRED',
                    'timestamp': datetime.now().isoformat()
                }
            }, status=status.HTTP_401_UNAUTHORIZED)
            
        indian_tz = pytz.timezone('Asia/Kolkata')
        user_timestamp = timezone.now().astimezone(indian_tz)
        
        if request.method == 'POST':
            try:
                data = request.data or request.body.decode('utf-8')
                bot_type = data.get('botType', "")
                input_text = data.get('message', "")
                user_input_text = data.get('message', "")
                document_id = data.get('documentId', None)
                session_id = data.get('sessionId', None)
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                logger.error(f"Failed to parse request body: {str(e)}")
                return Response({
                    'success': False,
                    'message': 'Invalid request format',
                    'error': {
                        'summary': 'Invalid request format',
                        'details': str(e),
                        'code': 'VALIDATION_ERROR'
                    }
                }, status=status.HTTP_400_BAD_REQUEST)
        
        document = None
        document_context = ""
        if document_id:
            try:
                document = UploadedDocument.objects.get(id=document_id)                
                if bot_type == 'document':
                    user_message = f'{user_input_text}'
                    processor = DocumentProcessor()
                    query_results = processor.query_document(str(document_id), input_text)
                    
                    if "error" in query_results:
                        logger.error(f"Document query error: {query_results['error']}")
                        return Response({
                            'success': False,
                            'message': f"Document Processing Error: {query_results['error']}",
                            'error': f"Document Processing Error: {query_results['error']}"
                        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                    
                    document_context = "\n\n".join(query_results["matched_chunks"])
                    input_text = f"""
                    User question: {input_text}
                    
                    Relevant document content:
                    {document_context}
                    
                    Based on the document content above, please answer the user's question.
                    """
                else:
                    user_message = f'{user_input_text}\n\n Uploaded File Name: {document.file_name}'
                    document_azure_path = document.azure_blob_path
                    document_content = asyncio.run(read_document(document_azure_path))
                    if document_content and isinstance(document_content, str):
                        input_text += document_content
                        
            except Exception as e:
                logger.error(f"Document processing error: {str(e)}")
                return Response({
                    'success': False,
                    'error': f"Document Processing Error: {str(e)}"
                }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            user_message = input_text
                
        if not bot_type or not input_text:
            missing_fields = {}
            if not bot_type:
                missing_fields['bot_type'] = 'This field is required'
            if not input_text:
                missing_fields['input_text'] = 'This field is required'
                                
            logger.error(f"Missing required fields: {missing_fields}")
            return Response({
                'success': False,
                'message': 'Missing required fields',
                'error': {
                    'summary': 'Missing required fields',
                    'details': missing_fields,
                    'code': 'VALIDATION_ERROR'
                }
            }, status=status.HTTP_400_BAD_REQUEST)

        input_count_token = count_tokens(input_text)
        MAX_TOKEN_LIMIT = 100000
        if input_count_token > MAX_TOKEN_LIMIT:
            return Response({
                'success': False,
                'error': f'Token limit exceeded! The maximum allowed limit is {MAX_TOKEN_LIMIT:,} tokens, '
                        f'but you have input {input_count_token:,} tokens.'
            }, status=status.HTTP_400_BAD_REQUEST)
         
        valid_bot_types = ["grammar", "email", "meeting_insights", "document"]
        if bot_type not in valid_bot_types:
            logger.error(f"Invalid task type: {bot_type}")
            return Response({
                'success': False,
                'message': f'Invalid Task Type - {bot_type}, It should be one of the {valid_bot_types}',  
                'error': {
                    'summary': 'Invalid TaskType',
                    'message': f'Invalid Task Type - {bot_type}, It should be one of the {valid_bot_types}',  
                    'code': 'VALIDATION_ERROR'
                }
            }, status=status.HTTP_400_BAD_REQUEST)

        auth = get_authentication_details(request)
        login_user_email = auth.get('login_email')
        login_token = auth.get('login_key')
            
        if not login_user_email or not login_token:
            return Response({
                'success': False,
                'message': 'Login Email or Login Token Missing',
                'error': {
                    'summary': 'Authentication required',
                    'details': 'Login Email or Login Token Missing',
                    'code': 'AUTH_ERROR'
                }
            }, status=status.HTTP_400_BAD_REQUEST)
            
        # Create initial chat message
        with transaction.atomic():
            chat_message = LAChatMessage.objects.create(
                user_email=login_user_email,
                session_id=session_id,
                bot_type=bot_type,
                delete_status=False,
                user_message=user_message,
                document=document if document else None,
                user_timestamp=user_timestamp,
                # Initialize with safe default values to prevent null constraint errors
                bot_response="",
                output_tokens=0,
                input_tokens=0,
                cached_content_token_count=0,
                total_cost=0,
                processing_error=""
            )
            
            chat_id = chat_message.id

        # Process the message with LLM
        answer = ""
        tokens = {
            "input_tokens": 0,
            "output_tokens": 0,
            "cached_content_token_count": 0,
            "total_cost": 0
        }
        llm_response_time = timedelta(seconds=0)
        error = None
        
        try:
            llm_start_time = time.time()
            llm_response = process_text_by_task(bot_type, input_text, login_token)
            
            answer = llm_response.get("answer", "")
            tokens = llm_response.get("usage", {})
            error = llm_response.get("error")
            
            # Handle potential missing or invalid data
            if not isinstance(tokens, dict):
                tokens = {
                    "input_tokens": 0,
                    "output_tokens": 0, 
                    "cached_content_token_count": 0,
                    "total_cost": 0
                }
            
            # Calculate LLM response time
            llm_execution_time = tokens.get('llm_response_time', time.time() - llm_start_time)
            llm_response_time = timedelta(seconds=int(llm_execution_time))
            
            # Handle LLM errors
            if error:
                logger.error(f"LLM Error in process_message: {error}")
                with transaction.atomic():
                    chat = LAChatMessage.objects.get(id=chat_id)
                    chat.query_response_status = False
                    chat.processing_error = str(error)
                    chat.llm_response_time = llm_response_time
                    chat.save()
                
                return Response({
                    'success': False,
                    'message': f'LLM Error: {error}',
                    'error': {
                        'summary': 'Unexpected response from LLM',
                        'details': f'LLM Error: {error}',
                        'code': 'LLM_ERROR'
                    }
                }, status=status.HTTP_400_BAD_REQUEST)
                
        except Exception as e:
            error = str(e)
            logger.error(f"Error in process_message LLM call: {error}")
            
            with transaction.atomic():
                chat = LAChatMessage.objects.get(id=chat_id)
                chat.query_response_status = False
                chat.processing_error = error
                chat.llm_response_time = llm_response_time
                chat.save()
            
            if error and isinstance(error, str):
                return Response({
                    'success': False,
                    'message': f'Processing Error: {error}',
                    'error': {
                        'summary': 'Error processing request',
                        'details': error,
                        'code': 'PROCESSING_ERROR'
                    }
                }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        # Update chat message with bot response
        bot_timestamp = timezone.now().astimezone(indian_tz)
        chat_title = Truncator(input_text).chars(90)
        
        # Ensure all values are valid to prevent null constraint errors
        safe_tokens = {
            "output_tokens": int(tokens.get("output_tokens", 0) or 0),
            "input_tokens": int(tokens.get("input_tokens", 0) or 0),
            "cached_content_token_count": int(tokens.get("cached_content_token_count", 0) or 0),
            "total_cost": float(tokens.get("total_cost", 0) or 0)
        }
        
        try:
            with transaction.atomic():
                chat = LAChatMessage.objects.get(id=chat_id)
                chat.bot_response = str(answer) if answer else ''
                chat.chat_title = chat_title
                chat.bot_timestamp = bot_timestamp
                chat.output_tokens = safe_tokens["output_tokens"]
                chat.input_tokens = safe_tokens["input_tokens"]
                chat.cached_content_token_count = safe_tokens["cached_content_token_count"]
                chat.total_cost = safe_tokens["total_cost"]
                chat.query_response_status = True
                chat.llm_response_time = llm_response_time
                chat.save()
        
        except ValidationError as ve:
            logger.error(f"Validation error updating chat: {str(ve)}")
            return Response({
                'success': False,
                'message': f'Validation error: {str(ve)}',
                'error': {
                    'summary': 'Data validation error',
                    'details': str(ve),
                    'code': 'VALIDATION_ERROR'
                }
            }, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            logger.error(f"Error updating chat record: {str(e)}")
            return Response({
                'success': False,
                'message': f'Database error: {str(e)}',
                'error': {
                    'summary': 'Database error',
                    'details': str(e),
                    'code': 'DB_ERROR'
                }
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        # Get updated chat history
        user_chat_data = filter_chat_data(request, bot_type, login_user_email)
        if user_chat_data is False:
            user_chat_data = []
            
        serializer = LAChatMessageSerializer(user_chat_data, many=True)
        chat_history = sorted(
            serializer.data, 
            key=lambda x: datetime.fromisoformat(x['created_at'].replace('Z', '+00:00')), 
            reverse=True
        ) if serializer.data else []
        
        execution_time = (time.time() - process_start_time)
        query_processing_time = timedelta(seconds=int(execution_time))
        
        # Update processing time
        try:
            LAChatMessage.objects.filter(id=chat_id).update(query_processing_time=query_processing_time)
        except Exception as e:
            logger.warning(f"Failed to update processing time: {str(e)}")
        
        return Response({
            "success": True,
            "chat_history": chat_history,
            "bot_response": chat.bot_response or error or "",
            "processing_time": execution_time
        }, status=status.HTTP_201_CREATED)
        
    except Exception as e:
        logger.error(f"Unhandled error in process_message: {str(e)}")
        return Response({
            'success': False,
            'message': 'An unexpected error occurred',
            'error': {
                'summary': 'Server error',
                'details': str(e),
                'code': 'SERVER_ERROR'
            }
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@csrf_exempt    
def filter_chat_data(request, bot_type, login_user_email, history_setting=True):   
    if request.user.is_authenticated:
        login_user_email = request.user.email
        login_token = request.session.session_key
        request.session['user_data'] = {
            'email': login_user_email,
            'login_key': login_token
        }
        request.session.modified = True
    else:
        if not login_user_email:
            return False
           
    user_chat_history = LAChatMessage.objects.filter(
        user_email=login_user_email, 
        bot_type=bot_type, 
        delete_status=False,
        query_response_status=True
    ).select_related()
    
    if not history_setting:
        user_chat_history = user_chat_history.filter(session_id=login_token)
                
    return user_chat_history


@csrf_exempt
def get_chat_sessions(request):
    bot_type = request.GET.get('bot_type')
    
    auth = get_authentication_details(request)
    user_email = auth.get('login_email')
        
    if not user_email:
        return Response({
            "success": False,
            "error": "Session Expired. Login Required",
            "message": "Session Expired. Login Required",
        })
    
    if not bot_type:
        return JsonResponse({
            'success': False,
            'error': 'Missing bot_type parameter'
        }, status=400)
    
    sessions = LAChatMessage.objects.filter(
        bot_type=bot_type,
        user_email=user_email,
        delete_status=False
    ).values('session_id').annotate(
        created_at=Min('created_at'),
        last_activity=Max('updated_at'),
        message_count=Count('id'),
        title=Max('chat_title')
    )
    
    session_data = []
    for session in sessions:
        first_message = LAChatMessage.objects.filter(
            session_id=session['session_id'],
            delete_status=False
        ).order_by('created_at').first()
        
        preview = None
        document_id = None
        
        if first_message:
            preview = first_message.user_message[:50] + ('...' if len(first_message.user_message) > 50 else '')
            if first_message.document:
                document_id = str(first_message.document.id)
        
        session_data.append({
            'id': session['session_id'],
            'title': session['title'] or 'Untitled Conversation',
            'created_at': session['created_at'],
            'last_activity': session['last_activity'],
            'message_count': session['message_count'],
            'preview': preview,
            'document_id': document_id
        })
    
    return JsonResponse({
        'success': True,
        'sessions': session_data
    })


@csrf_exempt
def get_messages_by_sessionid(request, bot_type, session_id):
    """
    Get all messages for a specific session
    
    URL parameters:
    - session_id: The ID of the chat session
    
    Returns:
    - JSON response with messages data
    """
    if not session_id or not bot_type:
        return JsonResponse({
            'success': False,
            'error': 'Missing required parameter : Bot Type or Session ID'
        }, status=400)
    
    try:
        decoded_session_id = urllib.parse.unquote(session_id)
    except:
        decoded_session_id = session_id    
    
    messages_query = LAChatMessage.objects.filter(
        session_id=decoded_session_id,
        bot_type=bot_type,
        delete_status=False
    ).order_by('created_at')
    
    if bot_type == 'document':
        try:
            document_id = UUID(decoded_session_id)
            document_messages = LAChatMessage.objects.filter(
                document__id=document_id,
                bot_type=bot_type,
                delete_status=False
            ).order_by('created_at')
            
            if document_messages.exists():
                messages_query = document_messages
        except ValueError:
            pass
            
        if messages_query.exists() and messages_query.first().document:
            document = messages_query.first().document
            document_messages = LAChatMessage.objects.filter(
                document=document,
                bot_type=bot_type,
                delete_status=False
            ).order_by('created_at')
            messages_query = document_messages
    
    messages = []
    for msg in messages_query:
        messages.append({
            'id': str(msg.id) + '_user',
            'content': msg.user_message,
            'sender': 'user',
            'timestamp': msg.user_timestamp,
            'sessionId': msg.session_id,
            'document_id': str(msg.document.id) if msg.document else None
        })
        
        messages.append({
            'id': str(msg.id) + '_bot',
            'content': msg.bot_response or f'{msg.processing_error}',
            'sender': 'bot',
            'timestamp': msg.bot_timestamp,
            'sessionId': msg.session_id,
            'document_id': str(msg.document.id) if msg.document else None
        })
    
    bot_type = messages_query.first().bot_type if messages_query.exists() else None
    document_id = str(messages_query.first().document.id) if messages_query.exists() and messages_query.first().document else None
    
    return JsonResponse({
        'success': True,
        'messages': messages,
        'bot_type': bot_type,
        'session_id': session_id,
        'document_id': document_id
    })


@csrf_exempt
def get_messages_by_document(request, document_id):
    """
    Get all messages for a specific document across all sessions
    
    URL parameters:
    - document_id: The ID of the document
    
    Returns:
    - JSON response with messages data
    """
    if not document_id:
        return JsonResponse({
            'success': False,
            'error': 'Missing required parameter: Document ID'
        }, status=400)
    
    try:
        doc_uuid = UUID(document_id)
        document = UploadedDocument.objects.filter(id=doc_uuid).first()
        if not document:
            return JsonResponse({
                'success': False,
                'error': f'Document with ID {document_id} not found'
            }, status=404)
        
        messages_query = LAChatMessage.objects.filter(
            document=document,
            bot_type='document',
            delete_status=False
        ).order_by('created_at')
        
        messages = []
        for msg in messages_query:
            messages.append({
                'id': str(msg.id) + '_user',
                'content': msg.user_message,
                'sender': 'user',
                'timestamp': msg.user_timestamp,
                'sessionId': msg.session_id,
                'document_id': str(document_id)
            })
            
            if msg.bot_response or msg.processing_error:
                messages.append({
                    'id': str(msg.id) + '_bot',
                    'content': msg.bot_response or f'{msg.processing_error}',
                    'sender': 'bot',
                    'timestamp': msg.bot_timestamp or msg.user_timestamp,
                    'sessionId': msg.session_id,
                    'document_id': str(document_id)
                })
        
        document_info = {
            'id': str(document.id),
            'name': document.file_name,
            'type': document.file_type,
            'url': document.file_url,
            'created_at': document.created_at
        }
        
        return JsonResponse({
            'success': True,
            'messages': messages,
            'document': document_info,
            'message_count': len(messages)
        })

    except ValueError:
        return JsonResponse({
            'success': False,
            'error': 'Invalid document ID format'
        }, status=400)
    except Exception as e:
        logger.error(f"Error fetching document messages: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': f'Error fetching document messages: {str(e)}'
        }, status=500)


@api_view(['DELETE'])
@csrf_exempt
def delete_session(request, bot_type, session_id):
    """
    Delete a chat session and all its messages
    """
    try:
        decoded_session_id = urllib.parse.unquote(session_id)
        
        messages = LAChatMessage.objects.filter(
            session_id=decoded_session_id,
            bot_type=bot_type
        )
        
        if not messages.exists():
            return JsonResponse({
                'success': True,
                'message': 'Session not found or already deleted.',
                'was_empty': True
            })
        
        # Soft delete by setting delete_status to True
        message_count = messages.update(delete_status=True)
        
        return JsonResponse({
            'success': True,
            'message': f'Session deleted successfully. {message_count} messages affected.',
        })        
    except Exception as e:
        logger.error(f"Error deleting session: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': f'Failed to delete session: {str(e)}'
        }, status=500)
        
        

@api_view(['DELETE'])
@csrf_exempt
def delete_message(request, bot_type, message_id):
    """
    Delete a specific message (both user question and bot response)
    
    URL parameters:
    - bot_type: Type of bot
    - message_id: ID of the message to delete
    
    Returns:
    - JSON response indicating success or failure
    """
    try:
        # Find the message by its ID
        try:
            # Remove the _user or _bot suffix if present
            original_id = message_id.split('_')[0]
            message = LAChatMessage.objects.get(
                id=original_id,
                bot_type=bot_type
            )
        except LAChatMessage.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Message not found'
            }, status=404)
        
        # Soft delete by setting delete_status to True
        message.delete_status = True
        message.save()
        
        return JsonResponse({
            'success': True,
            'message': 'Message deleted successfully',
        })
        
    except Exception as e:
        logger.error(f"Error deleting message: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': f'Failed to delete message: {str(e)}'
        }, status=500)


@csrf_exempt
def chatbot_user_guide_download(request):
    file_path = 'ChatBot/chatbotguide.pdf'
    file_name = 'chatbotguide.pdf'

    is_exists = AzureBlobManager(file_path).is_blob_exists()
    if not is_exists:
        return JsonResponse({
            'error': 'User Guide does not exist'
        }, status=404)

    file_content = AzureBlobManager(file_path).download_from_blob()
    file_base64 = base64.b64encode(file_content).decode('utf-8')

    file_type, _ = mimetypes.guess_type(file_path)
    if not file_type:
        file_type = "application/pdf"

    return JsonResponse({
        'file_name': file_name,
        'file_type': file_type,
        'file_data': file_base64
    })
