from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

import fitz
import psutil
import pytesseract
from PIL import Image
import concurrent.futures

import faiss
import numpy as np
import tiktoken
import os
import pickle
import time
import platform
from mimetypes import guess_type

from .azure_blob_manager import AzureBlobManager
from .utilities import *
from openai import AzureOpenAI, OpenAIError

import logging
logger = logging.getLogger(__name__)


class DocumentProcessor:
    def __init__(self, openai_client=None):
        """Initialize the document processor with optional OpenAI client."""
        self.openai_client = openai_client or AzureOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            azure_endpoint=os.getenv("OPENAI_API_BASE"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION")
        )
        
        if platform.system() == 'Windows':
            pytesseract.pytesseract.tesseract_cmd = os.path.join(r'C:\Users\arpit.patel\AppData\Local\Programs\Tesseract-OCR', 'tesseract.exe')
        else:
            pytesseract.pytesseract.tesseract_cmd = '/usr/bin/tesseract'
            os.environ['TESSDATA_PREFIX'] = '/usr/share/tesseract-ocr/4.00/tessdata'
        
        self.chunk_size = 2500
        self.chunk_overlap = 200
        self.batch_size = 50
        self.max_retries = 3
        logger.info("DocumentProcessor Initiated")
        
    def count_tokens(self, text, model="gpt-4o"):
        """Estimate token count for a given text using tiktoken."""
        encoding = tiktoken.encoding_for_model(model)
        return len(encoding.encode(text))
    
    def is_scanned_pdf(self, file_data):
        """Check if a PDF is scanned or contains selectable text."""
        doc = fitz.open(stream=file_data, filetype="pdf")
        for page in doc:
            text = page.get_text("text").strip()
            if text:
                return False
        return True
    
    def extract_text_from_pdf(self, file_data):
        """Extract text from a normal or scanned PDF."""
        doc = fitz.Document(stream=file_data, filetype="pdf")
        text = []
        
        is_scanned = True
        for page in doc:
            page_text = page.get_text("text").strip()
            if page_text:
                is_scanned = False
                break
                
        if is_scanned:
            logger.info("⚠️ Scanned PDF detected. Extracting using OCR...")
            for page_num in range(len(doc)):
                try:
                    pix = doc[page_num].get_pixmap()
                    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                    page_text = pytesseract.image_to_string(img)
                    text.append(page_text)
                except Exception as e:
                    logger.error(f"Error extracting text from page {page_num}: {str(e)}")
                    text.append(f"[ERROR EXTRACTING TEXT FROM PAGE {page_num}]")
        else:
            total_pages = len(doc)
            for batch_start in range(0, total_pages, self.batch_size):
                batch_end = min(batch_start + self.batch_size, total_pages)
                batch_text = []
                
                for page_num in range(batch_start, batch_end):
                    try:
                        page_text = doc[page_num].get_text("text")
                        batch_text.append(page_text)
                    except Exception as e:
                        logger.error(f"Error extracting text from page {page_num}: {str(e)}")
                        batch_text.append(f"[ERROR EXTRACTING TEXT FROM PAGE {page_num}]")
                
                text.extend(batch_text)
                logger.info(f"Processed pages {batch_start+1}-{batch_end} of {total_pages}")
        
        return "\n".join(text).strip()
    
    def update_chunk_size(self, document_text):
        """Dynamically adjust chunk size based on document length"""
        text_length = len(document_text)
        base_size = self.chunk_size
        
        if text_length < (base_size * 10):
            return base_size
        
        multipliers = [
            (50, 4),
            (100, 8),
            (float('inf'), 10)
        ]
        
        for threshold, multiplier in multipliers:
            if text_length < (base_size * threshold):
                return base_size * multiplier
        
        return base_size * 20
    
    def split_documents(self, document_text, source_name):
        """Split a document into chunks."""
        self.chunk_size = self.update_chunk_size(document_text)
        document = Document(page_content=document_text, metadata={"source": source_name})
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            add_start_index=True,
            strip_whitespace=True
        )
        
        return text_splitter.split_documents([document])
    
    def generate_embeddings(self, text_chunks):
        embeddings = []
        chunk_count = len(text_chunks)
        
        batch_size = 50
        def process_batch(batch_chunks):
            """Process a batch of chunks and return their embeddings."""
            batch_results = []
            chunk_texts = [chunk.page_content for chunk in batch_chunks]
            
            for attempt in range(self.max_retries):
                try:
                    response = self.openai_client.embeddings.create(
                        model="text-embedding-ada-002",
                        input=chunk_texts
                    )
                    batch_results = [data.embedding for data in response.data]
                    break
                except OpenAIError as e:
                    if attempt < self.max_retries - 1:
                        wait_time = 2 ** attempt
                        logger.warning(f"Embedding API Error: {e}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                    else:
                        logger.error(f"Final embedding API Error for batch: {e}")
                        logger.warning("Using zero embeddings as placeholders")
                        batch_results = [[0.0] * 1536 for _ in range(len(batch_chunks))]
            
            return batch_results
        
        batches = []
        for i in range(0, chunk_count, batch_size):
            batch_end = min(i + batch_size, chunk_count)
            batches.append(text_chunks[i:batch_end])
        
        logger.info(f"Processing {chunk_count} chunks in {len(batches)} batches")
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(process_batch, batch) for batch in batches]
            for i, future in enumerate(concurrent.futures.as_completed(futures)):
                batch_embeddings = future.result()
                embeddings.extend(batch_embeddings)
                logger.info(f"Completed batch {i+1}/{len(batches)}. Total progress: {min(len(embeddings), chunk_count)}/{chunk_count} chunks")
        
        assert len(embeddings) == chunk_count, f"Expected {chunk_count} embeddings, got {len(embeddings)}"        
        return embeddings
    
    # def generate_embeddings(self, text_chunks):
    #     """Generate embeddings for text chunks using Azure OpenAI in batches."""
    #     embeddings = []
    #     chunk_count = len(text_chunks)
        
    #     batch_size = 20
    #     for i in range(0, chunk_count, batch_size):
    #         batch_end = min(i + batch_size, chunk_count)
    #         batch_chunks = text_chunks[i:batch_end]
            
    #         logger.info(f"Generating embeddings for chunks {i+1}-{batch_end} of {chunk_count}")
            
    #         for chunk in batch_chunks:
    #             for attempt in range(self.max_retries):
    #                 try:
    #                     response = self.openai_client.embeddings.create(
    #                         model="text-embedding-ada-002",
    #                         input=[chunk.page_content]
    #                     )
    #                     embeddings.append(response.data[0].embedding)
    #                     break
    #                 except OpenAIError as e:
    #                     if attempt < self.max_retries - 1:
    #                         wait_time = 2 ** attempt
    #                         logger.warning(f"Embedding API Error: {e}. Retrying in {wait_time}s...")
    #                         time.sleep(wait_time)
    #                     else:
    #                         logger.error(f"Final embedding API Error for chunk: {e}")
    #                         logger.warning("Using a zero embedding as placeholder")
    #                         embeddings.append([0.0] * 1536)  # Standard embedding size
            
    #         if (batch_end % batch_size == 0 or batch_end == chunk_count) and embeddings:
    #             logger.info(f"Progress: {batch_end}/{chunk_count} chunks embedded")
        
    #     return embeddings
    
    def create_faiss_index(self, embeddings):
        """Create a FAISS index from the embeddings."""
        if not embeddings:
            logger.error("No embeddings found to create FAISS index")
            return None
            
        try:
            np_embeddings = np.array(embeddings, dtype=np.float32)
            if np_embeddings.size == 0:
                logger.error("Empty embeddings array")
                return None
                
            embedding_dim = np_embeddings.shape[1]
            faiss_index = faiss.IndexFlatL2(embedding_dim)
            
            batch_size = 1000
            for i in range(0, len(np_embeddings), batch_size):
                end_idx = min(i + batch_size, len(np_embeddings))
                faiss_index.add(np_embeddings[i:end_idx])
                
            logger.info(f"FAISS index created with {faiss_index.ntotal} vectors")
            return faiss_index
        except Exception as e:
            logger.error(f"Error creating FAISS index: {str(e)}")
            return None
    
    def process_document(self, document_content, file_name):
        """
        Process a document, split it into chunks, generate embeddings,
        and create a FAISS index with improved robustness.
        """
        start_time = time.time()
        logger.info(f"Starting to process document: {file_name}")
        
        try:
            mime_type, _ = guess_type(file_name.lower())
            if mime_type == 'text/plain':
                document_data = document_content.decode("utf-8")    
            elif mime_type == 'application/pdf':
                document_data = extract_text_from_pdf(document_content=document_content)
            elif mime_type in ["application/vnd.openxmlformats-officedocument.wordprocessingml.document", 
                            "application/msword"]:
                document_data = extract_text_from_docx(document_content)
            
            if not document_data or len(document_data.strip()) < 100:
                logger.warning(f"Document {file_name} contains little or no extractable text")
            
            chunks = self.split_documents(document_data, file_name)
            logger.info(f"Document split into {len(chunks)} chunks")
            
            if not chunks:
                logger.error(f"Failed to create chunks from document: {file_name}")
                return {
                    'chunks': [],
                    'faiss_index': None,
                    'processing_time': time.time() - start_time,
                    'error': 'Failed to create chunks from document'
                }
                        
            mem = psutil.virtual_memory()
            if mem.used / mem.total > 0.90:
                logger.warning(f"High memory usage detected ({mem.used / 1e6:.2f}MB / {mem.total / 1e6:.2f}MB). Aborting processing.")
                return {
                    'chunks': [],
                    'faiss_index': None,
                    'processing_time': time.time() - start_time,
                    'error': 'Server under heavy load, try uploading a smaller document.'
                }
            
            embeddings = self.generate_embeddings(chunks)
            valid_embeddings = [e for e in embeddings if not all(x == 0 for x in e)]
            logger.info(f"Generated {len(valid_embeddings)} valid embeddings out of {len(chunks)} chunks")
            
            faiss_index = self.create_faiss_index(valid_embeddings)
            
            processing_time = time.time() - start_time
            logger.info(f"Document processing completed in {processing_time:.2f} seconds")
            
            return {
                'chunks': chunks,
                'faiss_index': faiss_index,
                'processing_time': processing_time
            }
        except Exception as e:
            logger.error(f"Error processing document {file_name}: {str(e)}")
            processing_time = time.time() - start_time
            return {
                'chunks': [],
                'faiss_index': None,
                'processing_time': processing_time,
                'error': str(e)
            }
    
    def serialize_processing_results(self, results):
        """Serialize the processing results for storage with error handling."""
        try:
            chunks = results.get('chunks', [])
            faiss_index = results.get('faiss_index')
            
            if not chunks or faiss_index is None:
                error = results.get('error', 'Unknown error during processing')
                logger.error(f"Cannot serialize incomplete processing results: {error}")
                return None
            
            chunks_data = [
                {
                    'content': chunk.page_content,
                    'metadata': chunk.metadata
                } for chunk in chunks
            ]
            
            faiss_index_data = pickle.dumps(faiss_index)
            
            return {
                'chunks_data': pickle.dumps(chunks_data),
                'faiss_index_data': faiss_index_data
            }
        except Exception as e:
            logger.error(f"Error serializing processing results: {str(e)}")
            return None
    
    def save_to_azure_blob(self, document_id, serialized_data):
        """Save the processed document data to Azure Blob Storage with retries and verification."""
        if not serialized_data:
            logger.error(f"Cannot save empty serialized data for document {document_id}")
            return {
                'success': False,
                'error': 'No serialized data available to save'
            }
        
        chunks_blob_path = f'docbot_processed/{document_id}_chunks.pkl'
        index_blob_path = f'docbot_processed/{document_id}_index.pkl'        
        chunks_saved = self._save_blob_with_retry(chunks_blob_path, serialized_data['chunks_data'])        
        index_saved = self._save_blob_with_retry(index_blob_path, serialized_data['faiss_index_data'])
        
        if chunks_saved and index_saved:
            verification = self._verify_blobs_exist([chunks_blob_path, index_blob_path])
            if verification['success']:
                return {
                    'success': True,
                    'chunks_path': chunks_blob_path,
                    'index_path': index_blob_path
                }
            else:
                return {
                    'success': False,
                    'error': f"Verification failed: {verification['error']}"
                }
        else:
            if chunks_saved:
                self._delete_blob_with_retry(chunks_blob_path)
            if index_saved:
                self._delete_blob_with_retry(index_blob_path)
                
            return {
                'success': False,
                'error': 'Failed to save all required document files'
            }
    
    def _save_blob_with_retry(self, blob_path, data, max_retries=3):
        """Save blob with retry logic and exponential backoff."""
        for attempt in range(max_retries):
            try:
                blob_manager = AzureBlobManager(blob_path)
                blob_manager.upload_to_blob(data)
                logger.info(f"Successfully saved blob: {blob_path}")
                return True
            except Exception as e:
                wait_time = 2 ** attempt
                if attempt < max_retries - 1:
                    logger.warning(f"Error saving blob {blob_path}: {str(e)}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"Final error saving blob {blob_path}: {str(e)}")
        return False
    
    def _delete_blob_with_retry(self, blob_path, max_retries=3):
        """Delete blob with retry logic."""
        for attempt in range(max_retries):
            try:
                blob_manager = AzureBlobManager(blob_path)
                if blob_manager.delete_blob():
                    logger.info(f"Successfully deleted blob: {blob_path}")
                    return True
                return False
            except Exception as e:
                wait_time = 2 ** attempt
                if attempt < max_retries - 1:
                    logger.warning(f"Error deleting blob {blob_path}: {str(e)}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"Final error deleting blob {blob_path}: {str(e)}")
        return False
    
    def _verify_blobs_exist(self, blob_paths):
        """Verify that all specified blobs exist in Azure storage."""
        try:
            for path in blob_paths:
                blob_manager = AzureBlobManager(path)
                if not blob_manager.is_blob_exists():
                    return {
                        'success': False,
                        'error': f"Blob not found: {path}"
                    }
            return {
                'success': True
            }
        except Exception as e:
            return {
                'success': False,
                'error': f"Verification error: {str(e)}"
            }
    
    def load_from_azure_blob(self, document_id):
        """Load processed document data from Azure Blob Storage with robust error handling."""
        chunks_blob_path = f'docbot_processed/{document_id}_chunks.pkl'
        index_blob_path = f'docbot_processed/{document_id}_index.pkl'
        
        try:
            verification = self._verify_blobs_exist([chunks_blob_path, index_blob_path])
            if not verification['success']:
                logger.error(f"Verification failed: {verification.get('error')}")
                return {
                    "error": f"Document processing data not found: {verification.get('error')}"
                }
                
            chunks_data = None
            chunks_loaded = False
            for attempt in range(self.max_retries):
                try:
                    chunks_blob = AzureBlobManager(chunks_blob_path)
                    chunks_data = chunks_blob.download_from_blob()
                    chunks = pickle.loads(chunks_data)
                    chunks_loaded = True
                    break
                except Exception as e:
                    wait_time = 2 ** attempt
                    if attempt < self.max_retries - 1:
                        logger.warning(f"Error loading chunks from {chunks_blob_path}: {str(e)}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                    else:
                        logger.error(f"Final error loading chunks: {str(e)}")
            
            if not chunks_loaded:
                return {"error": "Failed to load document chunks after multiple attempts"}
            
            faiss_index = None
            index_loaded = False
            for attempt in range(self.max_retries):
                try:
                    index_blob = AzureBlobManager(index_blob_path)
                    index_data = index_blob.download_from_blob()
                    faiss_index = pickle.loads(index_data)
                    index_loaded = True
                    break
                except Exception as e:
                    wait_time = 2 ** attempt
                    if attempt < self.max_retries - 1:
                        logger.warning(f"Error loading index from {index_blob_path}: {str(e)}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                    else:
                        logger.error(f"Final error loading index: {str(e)}")
            
            if not index_loaded:
                return {"error": "Failed to load document index after multiple attempts"}
            
            return {
                'chunks': chunks,
                'faiss_index': faiss_index
            }
        except Exception as e:
            logger.error(f"Unexpected error loading processed data: {str(e)}")
            return {"error": f"Error loading document data: {str(e)}"}
    
    def query_document(self, document_id, query_text, top_k=4):
        """
        Query a processed document using the stored FAISS index with improved error handling.
        """
        processed_data = self.load_from_azure_blob(document_id)
        if "error" in processed_data:
            logger.error(f"Error loading document data: {processed_data['error']}")
            return {"error": processed_data["error"]}
        
        query_embedding = None
        for attempt in range(self.max_retries):
            try:
                query_response = self.openai_client.embeddings.create(
                    model="text-embedding-ada-002",
                    input=[query_text]
                )
                query_embedding = query_response.data[0].embedding
                break
            except OpenAIError as e:
                wait_time = 2 ** attempt
                if attempt < self.max_retries - 1:
                    logger.warning(f"Query embedding error: {str(e)}. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"Final query embedding error: {str(e)}")
        
        if query_embedding is None:
            return {"error": "Failed to generate query embedding"}
        
        try:
            faiss_index = processed_data['faiss_index']
            chunks = processed_data['chunks']
            
            if faiss_index.ntotal == 0:
                return {"error": "FAISS index is empty"}
            
            query_vector = np.array([query_embedding], dtype=np.float32)
            distances, indices = faiss_index.search(query_vector, min(top_k, faiss_index.ntotal))
            
            valid_indices = [i for i in indices[0] if i < len(chunks)]
            if not valid_indices:
                return {
                    "matched_chunks": ["No relevant content found in the document."],
                    "distances": []
                }
            
            matched_chunks = [chunks[i]['content'] for i in valid_indices]
            
            return {
                "matched_chunks": matched_chunks,
                "distances": distances[0].tolist()
            }
        except Exception as e:
            logger.error(f"Error querying document {document_id}: {str(e)}")
            return {"error": f"Error searching document: {str(e)}"}
        
        