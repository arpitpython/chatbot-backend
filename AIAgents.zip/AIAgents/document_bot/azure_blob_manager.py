from azure.storage.blob import BlobClient, BlobServiceClient, generate_blob_sas, AccountSasPermissions
from datetime import timedelta, datetime
import os


class AzureBlobManager:
    def __init__(self, blob_url):
        self.blob = BlobClient.from_connection_string(
            conn_str=os.environ.get('STORE_CONNECTION_STRING'),
            container_name='automation-apps-container',
            blob_name=blob_url
        )
        self.blob_con_str=os.environ.get('STORE_CONNECTION_STRING')
        self.blob_service_client = BlobServiceClient.from_connection_string(self.blob_con_str)
        self.container_client = self.blob_service_client.get_container_client('automation-apps-container')

    def upload_to_blob(self, file_data):
        self.blob.upload_blob(file_data, overwrite=True)

    def download_from_blob(self):
        download_stream = self.blob.download_blob()
        return download_stream.readall()

    def is_blob_exists(self):
        return self.blob.exists()

    def get_list_dirs(self, file_path):
        container_client = self.blob._get_container_client()
        prefix = f'{file_path}' if file_path.endswith('/') else f'{file_path}/'
        blob_iter = container_client.list_blobs(name_starts_with=prefix, delimiter='/')
        return [item.name.split('/')[-2] for item in blob_iter if item.name.endswith('/')]
    
    def delete_blob(self):
        if self.is_blob_exists():
            self.blob.delete_blob()
            return True
        else:
            return False

    def list_blobs_in_path(self, path):
        blob_service_client = BlobServiceClient.from_connection_string(self.blob_con_str)
        container_client = blob_service_client.get_container_client('automation-apps-container')

        blob_list = []

        # List all blobs in the container
        blobs = container_client.list_blobs(name_starts_with=path)
        for blob in blobs:
            blob_list.append(blob.name)

        return blob_list

    def download_blob(self, blob_name):
        blob_client = self.container_client.get_blob_client(blob_name)
        download_stream = blob_client.download_blob()
        return download_stream.readall()

    def upload_blob(self, blob_name, file):
        blob_client = self.blob_service_client.get_blob_client(container=self.container_client, blob=blob_name)
        blob_client.upload_blob(file.read(), overwrite=True)
    
    def generate_blob_sas_url(self, expiry_time_minutes=60):
        sas_token = generate_blob_sas(
            account_name=self.blob.account_name,
            container_name=self.blob.container_name,
            blob_name=self.blob.blob_name,
            account_key=self.blob.credential.account_key,
            permission=AccountSasPermissions(read=True),
            expiry=datetime.utcnow() + timedelta(minutes=expiry_time_minutes)
        )
        sas_url = f"{self.blob.url}?{sas_token}"
        
        if self.is_blob_exists():
            self.set_blob_inline_display()
            
        return sas_url
    
    def set_blob_inline_display(self):
        blob_properties = self.blob.get_blob_properties()
        content_settings = blob_properties.content_settings
        # content_settings.content_type = "application/pdf"
        content_settings.content_disposition = "inline"
        self.blob.set_http_headers(content_settings)
        return True

    